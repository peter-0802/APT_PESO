﻿namespace IMS_PESO
{
    partial class NSRP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox81 = new System.Windows.Forms.TextBox();
            this.textBox82 = new System.Windows.Forms.TextBox();
            this.textBox83 = new System.Windows.Forms.TextBox();
            this.comboBox11 = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.comboBox10 = new System.Windows.Forms.ComboBox();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.label67 = new System.Windows.Forms.Label();
            this.dateTimePicker6 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker7 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker8 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker9 = new System.Windows.Forms.DateTimePicker();
            this.label66 = new System.Windows.Forms.Label();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.dateTimePicker5 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker4 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.label65 = new System.Windows.Forms.Label();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.textBox78 = new System.Windows.Forms.TextBox();
            this.checkBox42 = new System.Windows.Forms.CheckBox();
            this.checkBox43 = new System.Windows.Forms.CheckBox();
            this.checkBox44 = new System.Windows.Forms.CheckBox();
            this.checkBox45 = new System.Windows.Forms.CheckBox();
            this.checkBox46 = new System.Windows.Forms.CheckBox();
            this.checkBox47 = new System.Windows.Forms.CheckBox();
            this.checkBox36 = new System.Windows.Forms.CheckBox();
            this.checkBox37 = new System.Windows.Forms.CheckBox();
            this.checkBox38 = new System.Windows.Forms.CheckBox();
            this.checkBox39 = new System.Windows.Forms.CheckBox();
            this.checkBox40 = new System.Windows.Forms.CheckBox();
            this.checkBox41 = new System.Windows.Forms.CheckBox();
            this.checkBox34 = new System.Windows.Forms.CheckBox();
            this.checkBox35 = new System.Windows.Forms.CheckBox();
            this.checkBox32 = new System.Windows.Forms.CheckBox();
            this.checkBox33 = new System.Windows.Forms.CheckBox();
            this.checkBox31 = new System.Windows.Forms.CheckBox();
            this.checkBox30 = new System.Windows.Forms.CheckBox();
            this.label110 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.dateTimePicker28 = new System.Windows.Forms.DateTimePicker();
            this.label99 = new System.Windows.Forms.Label();
            this.dateTimePicker29 = new System.Windows.Forms.DateTimePicker();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.dateTimePicker24 = new System.Windows.Forms.DateTimePicker();
            this.label98 = new System.Windows.Forms.Label();
            this.dateTimePicker25 = new System.Windows.Forms.DateTimePicker();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.dateTimePicker26 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker27 = new System.Windows.Forms.DateTimePicker();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.dateTimePicker22 = new System.Windows.Forms.DateTimePicker();
            this.label95 = new System.Windows.Forms.Label();
            this.dateTimePicker23 = new System.Windows.Forms.DateTimePicker();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label94 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.dateTimePicker18 = new System.Windows.Forms.DateTimePicker();
            this.label90 = new System.Windows.Forms.Label();
            this.textBox73 = new System.Windows.Forms.TextBox();
            this.dateTimePicker20 = new System.Windows.Forms.DateTimePicker();
            this.textBox74 = new System.Windows.Forms.TextBox();
            this.textBox75 = new System.Windows.Forms.TextBox();
            this.textBox76 = new System.Windows.Forms.TextBox();
            this.textBox77 = new System.Windows.Forms.TextBox();
            this.label89 = new System.Windows.Forms.Label();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.textBox62 = new System.Windows.Forms.TextBox();
            this.textBox64 = new System.Windows.Forms.TextBox();
            this.textBox66 = new System.Windows.Forms.TextBox();
            this.textBox72 = new System.Windows.Forms.TextBox();
            this.textBox70 = new System.Windows.Forms.TextBox();
            this.textBox71 = new System.Windows.Forms.TextBox();
            this.textBox69 = new System.Windows.Forms.TextBox();
            this.label92 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.textBox67 = new System.Windows.Forms.TextBox();
            this.textBox68 = new System.Windows.Forms.TextBox();
            this.label103 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.label85 = new System.Windows.Forms.Label();
            this.dateTimePicker15 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker16 = new System.Windows.Forms.DateTimePicker();
            this.label84 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.label82 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.dateTimePicker19 = new System.Windows.Forms.DateTimePicker();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.textBox63 = new System.Windows.Forms.TextBox();
            this.label86 = new System.Windows.Forms.Label();
            this.dateTimePicker21 = new System.Windows.Forms.DateTimePicker();
            this.textBox65 = new System.Windows.Forms.TextBox();
            this.label87 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.label73 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.dateTimePicker13 = new System.Windows.Forms.DateTimePicker();
            this.label80 = new System.Windows.Forms.Label();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.dateTimePicker14 = new System.Windows.Forms.DateTimePicker();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.dateTimePicker11 = new System.Windows.Forms.DateTimePicker();
            this.label76 = new System.Windows.Forms.Label();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.dateTimePicker12 = new System.Windows.Forms.DateTimePicker();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.dateTimePicker10 = new System.Windows.Forms.DateTimePicker();
            this.label72 = new System.Windows.Forms.Label();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.label79 = new System.Windows.Forms.Label();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.label78 = new System.Windows.Forms.Label();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.dateTimePicker17 = new System.Windows.Forms.DateTimePicker();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.label77 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.label55 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.checkBox26 = new System.Windows.Forms.CheckBox();
            this.label51 = new System.Windows.Forms.Label();
            this.checkBox27 = new System.Windows.Forms.CheckBox();
            this.checkBox28 = new System.Windows.Forms.CheckBox();
            this.checkBox29 = new System.Windows.Forms.CheckBox();
            this.checkBox22 = new System.Windows.Forms.CheckBox();
            this.checkBox23 = new System.Windows.Forms.CheckBox();
            this.checkBox24 = new System.Windows.Forms.CheckBox();
            this.checkBox25 = new System.Windows.Forms.CheckBox();
            this.label50 = new System.Windows.Forms.Label();
            this.checkBox21 = new System.Windows.Forms.CheckBox();
            this.checkBox20 = new System.Windows.Forms.CheckBox();
            this.checkBox19 = new System.Windows.Forms.CheckBox();
            this.checkBox18 = new System.Windows.Forms.CheckBox();
            this.label52 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.radioButton26 = new System.Windows.Forms.RadioButton();
            this.radioButton25 = new System.Windows.Forms.RadioButton();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.label30 = new System.Windows.Forms.Label();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.radioButton12 = new System.Windows.Forms.RadioButton();
            this.radioButton13 = new System.Windows.Forms.RadioButton();
            this.label31 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.label28 = new System.Windows.Forms.Label();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.radioButton11 = new System.Windows.Forms.RadioButton();
            this.label29 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label27 = new System.Windows.Forms.Label();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.label25 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.radioButton15 = new System.Windows.Forms.RadioButton();
            this.radioButton14 = new System.Windows.Forms.RadioButton();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.radioButton24 = new System.Windows.Forms.RadioButton();
            this.radioButton22 = new System.Windows.Forms.RadioButton();
            this.radioButton20 = new System.Windows.Forms.RadioButton();
            this.radioButton19 = new System.Windows.Forms.RadioButton();
            this.radioButton23 = new System.Windows.Forms.RadioButton();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.radioButton21 = new System.Windows.Forms.RadioButton();
            this.radioButton18 = new System.Windows.Forms.RadioButton();
            this.label24 = new System.Windows.Forms.Label();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.radioButton17 = new System.Windows.Forms.RadioButton();
            this.radioButton16 = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.bunifuSeparator2 = new Bunifu.Framework.UI.BunifuSeparator();
            this.label9 = new System.Windows.Forms.Label();
            this.bunifuSeparator1 = new Bunifu.Framework.UI.BunifuSeparator();
            this.panel1.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox22.SuspendLayout();
            this.groupBox21.SuspendLayout();
            this.groupBox20.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(16, 80);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(269, 24);
            this.textBox1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 57);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 18);
            this.label1.TabIndex = 1;
            this.label1.Text = "Surname";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(307, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 18);
            this.label2.TabIndex = 3;
            this.label2.Text = "First Name";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(311, 80);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(269, 24);
            this.textBox2.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(612, 57);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 18);
            this.label3.TabIndex = 5;
            this.label3.Text = "Middle Name";
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(616, 80);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(269, 24);
            this.textBox3.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(892, 57);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 18);
            this.label4.TabIndex = 7;
            this.label4.Text = "Suffix";
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Jr.",
            "Sr.",
            "III.",
            "IV."});
            this.comboBox1.Location = new System.Drawing.Point(895, 78);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(129, 26);
            this.comboBox1.TabIndex = 8;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "yyyy-MM-dd";
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(16, 149);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(269, 24);
            this.dateTimePicker1.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(13, 128);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 18);
            this.label5.TabIndex = 10;
            this.label5.Text = "Date of Birth:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(12, 191);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 18);
            this.label6.TabIndex = 12;
            this.label6.Text = "Sex:";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton1.Location = new System.Drawing.Point(6, 19);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(58, 22);
            this.radioButton1.TabIndex = 13;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Male";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton2.Location = new System.Drawing.Point(76, 19);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(75, 22);
            this.radioButton2.TabIndex = 14;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Female";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // comboBox2
            // 
            this.comboBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "-Select-",
            "Roman Catholic",
            "Islam"});
            this.comboBox2.Location = new System.Drawing.Point(16, 298);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(269, 26);
            this.comboBox2.TabIndex = 16;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(13, 275);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(74, 18);
            this.label7.TabIndex = 15;
            this.label7.Text = "Religion:";
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.textBox6);
            this.panel1.Controls.Add(this.textBox81);
            this.panel1.Controls.Add(this.textBox82);
            this.panel1.Controls.Add(this.textBox83);
            this.panel1.Controls.Add(this.comboBox11);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.comboBox10);
            this.panel1.Controls.Add(this.comboBox9);
            this.panel1.Controls.Add(this.comboBox8);
            this.panel1.Controls.Add(this.groupBox17);
            this.panel1.Controls.Add(this.groupBox22);
            this.panel1.Controls.Add(this.label110);
            this.panel1.Controls.Add(this.label100);
            this.panel1.Controls.Add(this.label97);
            this.panel1.Controls.Add(this.groupBox21);
            this.panel1.Controls.Add(this.label103);
            this.panel1.Controls.Add(this.label96);
            this.panel1.Controls.Add(this.groupBox20);
            this.panel1.Controls.Add(this.label104);
            this.panel1.Controls.Add(this.label81);
            this.panel1.Controls.Add(this.groupBox18);
            this.panel1.Controls.Add(this.label105);
            this.panel1.Controls.Add(this.label69);
            this.panel1.Controls.Add(this.label68);
            this.panel1.Controls.Add(this.groupBox16);
            this.panel1.Controls.Add(this.label56);
            this.panel1.Controls.Add(this.groupBox14);
            this.panel1.Controls.Add(this.label47);
            this.panel1.Controls.Add(this.groupBox12);
            this.panel1.Controls.Add(this.label32);
            this.panel1.Controls.Add(this.groupBox8);
            this.panel1.Controls.Add(this.label22);
            this.panel1.Controls.Add(this.groupBox5);
            this.panel1.Controls.Add(this.groupBox4);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.textBox9);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.textBox10);
            this.panel1.Controls.Add(this.label19);
            this.panel1.Controls.Add(this.textBox11);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.textBox12);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.textBox5);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.textBox4);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.bunifuSeparator2);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.bunifuSeparator1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.comboBox1);
            this.panel1.Controls.Add(this.comboBox2);
            this.panel1.Controls.Add(this.dateTimePicker1);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1100, 600);
            this.panel1.TabIndex = 19;
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.Location = new System.Drawing.Point(154, 456);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(340, 24);
            this.textBox6.TabIndex = 139;
            // 
            // textBox81
            // 
            this.textBox81.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox81.Location = new System.Drawing.Point(154, 425);
            this.textBox81.Name = "textBox81";
            this.textBox81.Size = new System.Drawing.Size(340, 24);
            this.textBox81.TabIndex = 138;
            // 
            // textBox82
            // 
            this.textBox82.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox82.Location = new System.Drawing.Point(154, 395);
            this.textBox82.Name = "textBox82";
            this.textBox82.Size = new System.Drawing.Size(340, 24);
            this.textBox82.TabIndex = 137;
            // 
            // textBox83
            // 
            this.textBox83.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox83.Location = new System.Drawing.Point(155, 365);
            this.textBox83.Name = "textBox83";
            this.textBox83.Size = new System.Drawing.Size(340, 24);
            this.textBox83.TabIndex = 136;
            // 
            // comboBox11
            // 
            this.comboBox11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.comboBox11.FormattingEnabled = true;
            this.comboBox11.Items.AddRange(new object[] {
            "-Select-",
            "Single",
            "Married",
            "Widowed",
            "Separated",
            "Live-In"});
            this.comboBox11.Location = new System.Drawing.Point(104, 333);
            this.comboBox11.Name = "comboBox11";
            this.comboBox11.Size = new System.Drawing.Size(181, 26);
            this.comboBox11.TabIndex = 135;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(949, 2610);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 132;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // comboBox10
            // 
            this.comboBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.comboBox10.FormattingEnabled = true;
            this.comboBox10.Items.AddRange(new object[] {
            "-Select-",
            "Davao del Sur",
            "Davao del Norte",
            "Davao De Oro"});
            this.comboBox10.Location = new System.Drawing.Point(490, 303);
            this.comboBox10.Name = "comboBox10";
            this.comboBox10.Size = new System.Drawing.Size(533, 26);
            this.comboBox10.TabIndex = 131;
            // 
            // comboBox9
            // 
            this.comboBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.Items.AddRange(new object[] {
            "-Select-",
            "Magsaysay",
            "Bansalan",
            "Digos City"});
            this.comboBox9.Location = new System.Drawing.Point(491, 272);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(533, 26);
            this.comboBox9.TabIndex = 130;
            // 
            // comboBox8
            // 
            this.comboBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Items.AddRange(new object[] {
            "-Select-",
            "Barangay 1",
            "Barangay 2",
            "Barangay 3",
            "Barangay 4"});
            this.comboBox8.Location = new System.Drawing.Point(491, 242);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(533, 26);
            this.comboBox8.TabIndex = 129;
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.textBox44);
            this.groupBox17.Controls.Add(this.textBox45);
            this.groupBox17.Controls.Add(this.textBox46);
            this.groupBox17.Controls.Add(this.textBox47);
            this.groupBox17.Controls.Add(this.label67);
            this.groupBox17.Controls.Add(this.dateTimePicker6);
            this.groupBox17.Controls.Add(this.dateTimePicker7);
            this.groupBox17.Controls.Add(this.dateTimePicker8);
            this.groupBox17.Controls.Add(this.dateTimePicker9);
            this.groupBox17.Controls.Add(this.label66);
            this.groupBox17.Controls.Add(this.textBox40);
            this.groupBox17.Controls.Add(this.textBox41);
            this.groupBox17.Controls.Add(this.textBox42);
            this.groupBox17.Controls.Add(this.textBox43);
            this.groupBox17.Controls.Add(this.dateTimePicker5);
            this.groupBox17.Controls.Add(this.dateTimePicker4);
            this.groupBox17.Controls.Add(this.dateTimePicker3);
            this.groupBox17.Controls.Add(this.dateTimePicker2);
            this.groupBox17.Controls.Add(this.textBox36);
            this.groupBox17.Controls.Add(this.textBox39);
            this.groupBox17.Controls.Add(this.textBox32);
            this.groupBox17.Controls.Add(this.textBox37);
            this.groupBox17.Controls.Add(this.textBox34);
            this.groupBox17.Controls.Add(this.label61);
            this.groupBox17.Controls.Add(this.label62);
            this.groupBox17.Controls.Add(this.label63);
            this.groupBox17.Controls.Add(this.textBox38);
            this.groupBox17.Controls.Add(this.textBox33);
            this.groupBox17.Controls.Add(this.textBox35);
            this.groupBox17.Controls.Add(this.label65);
            this.groupBox17.Location = new System.Drawing.Point(13, 1634);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(1011, 204);
            this.groupBox17.TabIndex = 80;
            this.groupBox17.TabStop = false;
            // 
            // textBox44
            // 
            this.textBox44.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox44.Location = new System.Drawing.Point(871, 165);
            this.textBox44.Multiline = true;
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(134, 20);
            this.textBox44.TabIndex = 108;
            // 
            // textBox45
            // 
            this.textBox45.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox45.Location = new System.Drawing.Point(871, 33);
            this.textBox45.Multiline = true;
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(134, 20);
            this.textBox45.TabIndex = 105;
            // 
            // textBox46
            // 
            this.textBox46.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox46.Location = new System.Drawing.Point(871, 121);
            this.textBox46.Multiline = true;
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(134, 20);
            this.textBox46.TabIndex = 107;
            // 
            // textBox47
            // 
            this.textBox47.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox47.Location = new System.Drawing.Point(871, 77);
            this.textBox47.Multiline = true;
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(134, 20);
            this.textBox47.TabIndex = 106;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.Location = new System.Drawing.Point(735, 16);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(115, 16);
            this.label67.TabIndex = 104;
            this.label67.Text = "year last attended";
            // 
            // dateTimePicker6
            // 
            this.dateTimePicker6.CustomFormat = "yyyy";
            this.dateTimePicker6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker6.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker6.Location = new System.Drawing.Point(737, 165);
            this.dateTimePicker6.Name = "dateTimePicker6";
            this.dateTimePicker6.Size = new System.Drawing.Size(110, 22);
            this.dateTimePicker6.TabIndex = 103;
            // 
            // dateTimePicker7
            // 
            this.dateTimePicker7.CustomFormat = "yyyy";
            this.dateTimePicker7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker7.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker7.Location = new System.Drawing.Point(738, 121);
            this.dateTimePicker7.Name = "dateTimePicker7";
            this.dateTimePicker7.Size = new System.Drawing.Size(110, 22);
            this.dateTimePicker7.TabIndex = 102;
            // 
            // dateTimePicker8
            // 
            this.dateTimePicker8.CustomFormat = "yyyy";
            this.dateTimePicker8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker8.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker8.Location = new System.Drawing.Point(737, 77);
            this.dateTimePicker8.Name = "dateTimePicker8";
            this.dateTimePicker8.Size = new System.Drawing.Size(110, 22);
            this.dateTimePicker8.TabIndex = 101;
            // 
            // dateTimePicker9
            // 
            this.dateTimePicker9.CustomFormat = "yyyy";
            this.dateTimePicker9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker9.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker9.Location = new System.Drawing.Point(737, 33);
            this.dateTimePicker9.Name = "dateTimePicker9";
            this.dateTimePicker9.Size = new System.Drawing.Size(110, 22);
            this.dateTimePicker9.TabIndex = 100;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.Location = new System.Drawing.Point(646, 16);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(74, 16);
            this.label66.TabIndex = 87;
            this.label66.Text = "what level?";
            // 
            // textBox40
            // 
            this.textBox40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox40.Location = new System.Drawing.Point(649, 167);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(71, 22);
            this.textBox40.TabIndex = 99;
            // 
            // textBox41
            // 
            this.textBox41.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox41.Location = new System.Drawing.Point(649, 35);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(71, 22);
            this.textBox41.TabIndex = 96;
            // 
            // textBox42
            // 
            this.textBox42.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox42.Location = new System.Drawing.Point(649, 123);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(71, 22);
            this.textBox42.TabIndex = 98;
            // 
            // textBox43
            // 
            this.textBox43.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox43.Location = new System.Drawing.Point(649, 79);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(71, 22);
            this.textBox43.TabIndex = 97;
            // 
            // dateTimePicker5
            // 
            this.dateTimePicker5.CustomFormat = "yyyy";
            this.dateTimePicker5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker5.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker5.Location = new System.Drawing.Point(488, 167);
            this.dateTimePicker5.Name = "dateTimePicker5";
            this.dateTimePicker5.Size = new System.Drawing.Size(127, 22);
            this.dateTimePicker5.TabIndex = 95;
            // 
            // dateTimePicker4
            // 
            this.dateTimePicker4.CustomFormat = "yyyy";
            this.dateTimePicker4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker4.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker4.Location = new System.Drawing.Point(489, 123);
            this.dateTimePicker4.Name = "dateTimePicker4";
            this.dateTimePicker4.Size = new System.Drawing.Size(127, 22);
            this.dateTimePicker4.TabIndex = 94;
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.CustomFormat = "yyyy";
            this.dateTimePicker3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker3.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker3.Location = new System.Drawing.Point(488, 79);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(127, 22);
            this.dateTimePicker3.TabIndex = 93;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.CustomFormat = "yyyy";
            this.dateTimePicker2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker2.Location = new System.Drawing.Point(488, 35);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(127, 22);
            this.dateTimePicker2.TabIndex = 92;
            // 
            // textBox36
            // 
            this.textBox36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox36.Location = new System.Drawing.Point(310, 167);
            this.textBox36.Multiline = true;
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(154, 20);
            this.textBox36.TabIndex = 91;
            // 
            // textBox39
            // 
            this.textBox39.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox39.Location = new System.Drawing.Point(310, 35);
            this.textBox39.Multiline = true;
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(154, 20);
            this.textBox39.TabIndex = 88;
            // 
            // textBox32
            // 
            this.textBox32.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox32.Location = new System.Drawing.Point(12, 35);
            this.textBox32.Multiline = true;
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(271, 20);
            this.textBox32.TabIndex = 80;
            // 
            // textBox37
            // 
            this.textBox37.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox37.Location = new System.Drawing.Point(310, 123);
            this.textBox37.Multiline = true;
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(154, 20);
            this.textBox37.TabIndex = 90;
            // 
            // textBox34
            // 
            this.textBox34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox34.Location = new System.Drawing.Point(12, 167);
            this.textBox34.Multiline = true;
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(271, 20);
            this.textBox34.TabIndex = 86;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.Location = new System.Drawing.Point(9, 16);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(76, 16);
            this.label61.TabIndex = 81;
            this.label61.Text = "Elementary";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.Location = new System.Drawing.Point(9, 60);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(74, 16);
            this.label62.TabIndex = 83;
            this.label62.Text = "Secondary";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.Location = new System.Drawing.Point(9, 148);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(112, 16);
            this.label63.TabIndex = 87;
            this.label63.Text = "Graduate Studies";
            // 
            // textBox38
            // 
            this.textBox38.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox38.Location = new System.Drawing.Point(310, 79);
            this.textBox38.Multiline = true;
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(154, 20);
            this.textBox38.TabIndex = 89;
            // 
            // textBox33
            // 
            this.textBox33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox33.Location = new System.Drawing.Point(12, 79);
            this.textBox33.Multiline = true;
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(271, 20);
            this.textBox33.TabIndex = 82;
            // 
            // textBox35
            // 
            this.textBox35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox35.Location = new System.Drawing.Point(12, 123);
            this.textBox35.Multiline = true;
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(271, 20);
            this.textBox35.TabIndex = 84;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.Location = new System.Drawing.Point(9, 104);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(54, 16);
            this.label65.TabIndex = 85;
            this.label65.Text = "Tertiary";
            // 
            // groupBox22
            // 
            this.groupBox22.Controls.Add(this.textBox78);
            this.groupBox22.Controls.Add(this.checkBox42);
            this.groupBox22.Controls.Add(this.checkBox43);
            this.groupBox22.Controls.Add(this.checkBox44);
            this.groupBox22.Controls.Add(this.checkBox45);
            this.groupBox22.Controls.Add(this.checkBox46);
            this.groupBox22.Controls.Add(this.checkBox47);
            this.groupBox22.Controls.Add(this.checkBox36);
            this.groupBox22.Controls.Add(this.checkBox37);
            this.groupBox22.Controls.Add(this.checkBox38);
            this.groupBox22.Controls.Add(this.checkBox39);
            this.groupBox22.Controls.Add(this.checkBox40);
            this.groupBox22.Controls.Add(this.checkBox41);
            this.groupBox22.Controls.Add(this.checkBox34);
            this.groupBox22.Controls.Add(this.checkBox35);
            this.groupBox22.Controls.Add(this.checkBox32);
            this.groupBox22.Controls.Add(this.checkBox33);
            this.groupBox22.Controls.Add(this.checkBox31);
            this.groupBox22.Controls.Add(this.checkBox30);
            this.groupBox22.Location = new System.Drawing.Point(13, 2416);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Size = new System.Drawing.Size(1011, 188);
            this.groupBox22.TabIndex = 128;
            this.groupBox22.TabStop = false;
            // 
            // textBox78
            // 
            this.textBox78.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox78.Location = new System.Drawing.Point(651, 159);
            this.textBox78.Multiline = true;
            this.textBox78.Name = "textBox78";
            this.textBox78.Size = new System.Drawing.Size(341, 20);
            this.textBox78.TabIndex = 166;
            // 
            // checkBox42
            // 
            this.checkBox42.AutoSize = true;
            this.checkBox42.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox42.Location = new System.Drawing.Point(551, 159);
            this.checkBox42.Name = "checkBox42";
            this.checkBox42.Size = new System.Drawing.Size(94, 22);
            this.checkBox42.TabIndex = 104;
            this.checkBox42.Text = "OTHERS:";
            this.checkBox42.UseVisualStyleBackColor = true;
            // 
            // checkBox43
            // 
            this.checkBox43.AutoSize = true;
            this.checkBox43.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox43.Location = new System.Drawing.Point(551, 131);
            this.checkBox43.Name = "checkBox43";
            this.checkBox43.Size = new System.Drawing.Size(105, 22);
            this.checkBox43.TabIndex = 103;
            this.checkBox43.Text = "TAILORING";
            this.checkBox43.UseVisualStyleBackColor = true;
            // 
            // checkBox44
            // 
            this.checkBox44.AutoSize = true;
            this.checkBox44.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox44.Location = new System.Drawing.Point(551, 103);
            this.checkBox44.Name = "checkBox44";
            this.checkBox44.Size = new System.Drawing.Size(141, 22);
            this.checkBox44.TabIndex = 102;
            this.checkBox44.Text = "STENOGRAPHY";
            this.checkBox44.UseVisualStyleBackColor = true;
            // 
            // checkBox45
            // 
            this.checkBox45.AutoSize = true;
            this.checkBox45.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox45.Location = new System.Drawing.Point(551, 75);
            this.checkBox45.Name = "checkBox45";
            this.checkBox45.Size = new System.Drawing.Size(164, 22);
            this.checkBox45.TabIndex = 101;
            this.checkBox45.Text = "SEWING DRESSES";
            this.checkBox45.UseVisualStyleBackColor = true;
            // 
            // checkBox46
            // 
            this.checkBox46.AutoSize = true;
            this.checkBox46.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox46.Location = new System.Drawing.Point(551, 47);
            this.checkBox46.Name = "checkBox46";
            this.checkBox46.Size = new System.Drawing.Size(105, 22);
            this.checkBox46.TabIndex = 100;
            this.checkBox46.Text = "PLUMBING";
            this.checkBox46.UseVisualStyleBackColor = true;
            // 
            // checkBox47
            // 
            this.checkBox47.AutoSize = true;
            this.checkBox47.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox47.Location = new System.Drawing.Point(551, 19);
            this.checkBox47.Name = "checkBox47";
            this.checkBox47.Size = new System.Drawing.Size(143, 22);
            this.checkBox47.TabIndex = 99;
            this.checkBox47.Text = "PHOTOGRAPHY";
            this.checkBox47.UseVisualStyleBackColor = true;
            // 
            // checkBox36
            // 
            this.checkBox36.AutoSize = true;
            this.checkBox36.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox36.Location = new System.Drawing.Point(308, 159);
            this.checkBox36.Name = "checkBox36";
            this.checkBox36.Size = new System.Drawing.Size(139, 22);
            this.checkBox36.TabIndex = 98;
            this.checkBox36.Text = "PAINTING JOBS";
            this.checkBox36.UseVisualStyleBackColor = true;
            // 
            // checkBox37
            // 
            this.checkBox37.AutoSize = true;
            this.checkBox37.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox37.Location = new System.Drawing.Point(308, 131);
            this.checkBox37.Name = "checkBox37";
            this.checkBox37.Size = new System.Drawing.Size(145, 22);
            this.checkBox37.TabIndex = 97;
            this.checkBox37.Text = "PAINTER/ARTIST";
            this.checkBox37.UseVisualStyleBackColor = true;
            // 
            // checkBox38
            // 
            this.checkBox38.AutoSize = true;
            this.checkBox38.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox38.Location = new System.Drawing.Point(308, 103);
            this.checkBox38.Name = "checkBox38";
            this.checkBox38.Size = new System.Drawing.Size(102, 22);
            this.checkBox38.TabIndex = 96;
            this.checkBox38.Text = "MASONRY";
            this.checkBox38.UseVisualStyleBackColor = true;
            // 
            // checkBox39
            // 
            this.checkBox39.AutoSize = true;
            this.checkBox39.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox39.Location = new System.Drawing.Point(308, 75);
            this.checkBox39.Name = "checkBox39";
            this.checkBox39.Size = new System.Drawing.Size(117, 22);
            this.checkBox39.TabIndex = 95;
            this.checkBox39.Text = "GARDENING";
            this.checkBox39.UseVisualStyleBackColor = true;
            // 
            // checkBox40
            // 
            this.checkBox40.AutoSize = true;
            this.checkBox40.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox40.Location = new System.Drawing.Point(308, 47);
            this.checkBox40.Name = "checkBox40";
            this.checkBox40.Size = new System.Drawing.Size(127, 22);
            this.checkBox40.TabIndex = 94;
            this.checkBox40.Text = "EMBROIDERY";
            this.checkBox40.UseVisualStyleBackColor = true;
            // 
            // checkBox41
            // 
            this.checkBox41.AutoSize = true;
            this.checkBox41.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox41.Location = new System.Drawing.Point(308, 19);
            this.checkBox41.Name = "checkBox41";
            this.checkBox41.Size = new System.Drawing.Size(123, 22);
            this.checkBox41.TabIndex = 93;
            this.checkBox41.Text = "ELECTRICIAN";
            this.checkBox41.UseVisualStyleBackColor = true;
            // 
            // checkBox34
            // 
            this.checkBox34.AutoSize = true;
            this.checkBox34.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox34.Location = new System.Drawing.Point(12, 159);
            this.checkBox34.Name = "checkBox34";
            this.checkBox34.Size = new System.Drawing.Size(82, 22);
            this.checkBox34.TabIndex = 92;
            this.checkBox34.Text = "DRIVER";
            this.checkBox34.UseVisualStyleBackColor = true;
            // 
            // checkBox35
            // 
            this.checkBox35.AutoSize = true;
            this.checkBox35.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox35.Location = new System.Drawing.Point(12, 131);
            this.checkBox35.Name = "checkBox35";
            this.checkBox35.Size = new System.Drawing.Size(175, 22);
            this.checkBox35.TabIndex = 91;
            this.checkBox35.Text = "DOMESTIC CHORES";
            this.checkBox35.UseVisualStyleBackColor = true;
            // 
            // checkBox32
            // 
            this.checkBox32.AutoSize = true;
            this.checkBox32.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox32.Location = new System.Drawing.Point(12, 103);
            this.checkBox32.Name = "checkBox32";
            this.checkBox32.Size = new System.Drawing.Size(187, 22);
            this.checkBox32.TabIndex = 90;
            this.checkBox32.Text = "COMPUTER LITERATE";
            this.checkBox32.UseVisualStyleBackColor = true;
            // 
            // checkBox33
            // 
            this.checkBox33.AutoSize = true;
            this.checkBox33.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox33.Location = new System.Drawing.Point(12, 75);
            this.checkBox33.Name = "checkBox33";
            this.checkBox33.Size = new System.Drawing.Size(170, 22);
            this.checkBox33.TabIndex = 89;
            this.checkBox33.Text = "CARPENTRY WORK";
            this.checkBox33.UseVisualStyleBackColor = true;
            // 
            // checkBox31
            // 
            this.checkBox31.AutoSize = true;
            this.checkBox31.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox31.Location = new System.Drawing.Point(12, 47);
            this.checkBox31.Name = "checkBox31";
            this.checkBox31.Size = new System.Drawing.Size(113, 22);
            this.checkBox31.TabIndex = 88;
            this.checkBox31.Text = "BEAUTICIAN";
            this.checkBox31.UseVisualStyleBackColor = true;
            // 
            // checkBox30
            // 
            this.checkBox30.AutoSize = true;
            this.checkBox30.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox30.Location = new System.Drawing.Point(12, 19);
            this.checkBox30.Name = "checkBox30";
            this.checkBox30.Size = new System.Drawing.Size(151, 22);
            this.checkBox30.TabIndex = 87;
            this.checkBox30.Text = "AUTO MECHANIC";
            this.checkBox30.UseVisualStyleBackColor = true;
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label110.Location = new System.Drawing.Point(10, 2395);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(443, 18);
            this.label110.TabIndex = 127;
            this.label110.Text = "OTHER SKILL ACQUIRED WITHOUT FORMAL TRAINING";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label100.Location = new System.Drawing.Point(19, 459);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(129, 18);
            this.label100.TabIndex = 111;
            this.label100.Text = "PHILHEALTH NO.";
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label97.Location = new System.Drawing.Point(187, 2174);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(430, 18);
            this.label97.TabIndex = 126;
            this.label97.Text = "(Limit to 10 years period, start with the most recent employment)";
            // 
            // groupBox21
            // 
            this.groupBox21.Controls.Add(this.comboBox7);
            this.groupBox21.Controls.Add(this.dateTimePicker28);
            this.groupBox21.Controls.Add(this.label99);
            this.groupBox21.Controls.Add(this.dateTimePicker29);
            this.groupBox21.Controls.Add(this.comboBox5);
            this.groupBox21.Controls.Add(this.dateTimePicker24);
            this.groupBox21.Controls.Add(this.label98);
            this.groupBox21.Controls.Add(this.dateTimePicker25);
            this.groupBox21.Controls.Add(this.comboBox6);
            this.groupBox21.Controls.Add(this.dateTimePicker26);
            this.groupBox21.Controls.Add(this.dateTimePicker27);
            this.groupBox21.Controls.Add(this.comboBox4);
            this.groupBox21.Controls.Add(this.dateTimePicker22);
            this.groupBox21.Controls.Add(this.label95);
            this.groupBox21.Controls.Add(this.dateTimePicker23);
            this.groupBox21.Controls.Add(this.comboBox3);
            this.groupBox21.Controls.Add(this.label94);
            this.groupBox21.Controls.Add(this.label91);
            this.groupBox21.Controls.Add(this.dateTimePicker18);
            this.groupBox21.Controls.Add(this.label90);
            this.groupBox21.Controls.Add(this.textBox73);
            this.groupBox21.Controls.Add(this.dateTimePicker20);
            this.groupBox21.Controls.Add(this.textBox74);
            this.groupBox21.Controls.Add(this.textBox75);
            this.groupBox21.Controls.Add(this.textBox76);
            this.groupBox21.Controls.Add(this.textBox77);
            this.groupBox21.Controls.Add(this.label89);
            this.groupBox21.Controls.Add(this.textBox60);
            this.groupBox21.Controls.Add(this.textBox62);
            this.groupBox21.Controls.Add(this.textBox64);
            this.groupBox21.Controls.Add(this.textBox66);
            this.groupBox21.Controls.Add(this.textBox72);
            this.groupBox21.Controls.Add(this.textBox70);
            this.groupBox21.Controls.Add(this.textBox71);
            this.groupBox21.Controls.Add(this.textBox69);
            this.groupBox21.Controls.Add(this.label92);
            this.groupBox21.Controls.Add(this.label93);
            this.groupBox21.Controls.Add(this.textBox67);
            this.groupBox21.Controls.Add(this.textBox68);
            this.groupBox21.Location = new System.Drawing.Point(13, 2195);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Size = new System.Drawing.Size(1011, 188);
            this.groupBox21.TabIndex = 125;
            this.groupBox21.TabStop = false;
            // 
            // comboBox7
            // 
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Items.AddRange(new object[] {
            "Permanent",
            "Contractual",
            "Part Time",
            "Probationary"});
            this.comboBox7.Location = new System.Drawing.Point(871, 151);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(121, 21);
            this.comboBox7.TabIndex = 165;
            // 
            // dateTimePicker28
            // 
            this.dateTimePicker28.CustomFormat = "MM/dd/yyyy";
            this.dateTimePicker28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker28.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker28.Location = new System.Drawing.Point(765, 150);
            this.dateTimePicker28.Name = "dateTimePicker28";
            this.dateTimePicker28.Size = new System.Drawing.Size(85, 22);
            this.dateTimePicker28.TabIndex = 164;
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label99.Location = new System.Drawing.Point(740, 152);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(19, 16);
            this.label99.TabIndex = 163;
            this.label99.Text = "to";
            // 
            // dateTimePicker29
            // 
            this.dateTimePicker29.CustomFormat = "MM/dd/yyyy";
            this.dateTimePicker29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker29.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker29.Location = new System.Drawing.Point(649, 150);
            this.dateTimePicker29.Name = "dateTimePicker29";
            this.dateTimePicker29.Size = new System.Drawing.Size(85, 22);
            this.dateTimePicker29.TabIndex = 162;
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Items.AddRange(new object[] {
            "Permanent",
            "Contractual",
            "Part Time",
            "Probationary"});
            this.comboBox5.Location = new System.Drawing.Point(871, 127);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(121, 21);
            this.comboBox5.TabIndex = 161;
            // 
            // dateTimePicker24
            // 
            this.dateTimePicker24.CustomFormat = "MM/dd/yyyy";
            this.dateTimePicker24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker24.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker24.Location = new System.Drawing.Point(765, 126);
            this.dateTimePicker24.Name = "dateTimePicker24";
            this.dateTimePicker24.Size = new System.Drawing.Size(85, 22);
            this.dateTimePicker24.TabIndex = 160;
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label98.Location = new System.Drawing.Point(740, 128);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(19, 16);
            this.label98.TabIndex = 159;
            this.label98.Text = "to";
            // 
            // dateTimePicker25
            // 
            this.dateTimePicker25.CustomFormat = "MM/dd/yyyy";
            this.dateTimePicker25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker25.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker25.Location = new System.Drawing.Point(649, 126);
            this.dateTimePicker25.Name = "dateTimePicker25";
            this.dateTimePicker25.Size = new System.Drawing.Size(85, 22);
            this.dateTimePicker25.TabIndex = 158;
            // 
            // comboBox6
            // 
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Items.AddRange(new object[] {
            "Permanent",
            "Contractual",
            "Part Time",
            "Probationary"});
            this.comboBox6.Location = new System.Drawing.Point(871, 99);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(121, 21);
            this.comboBox6.TabIndex = 157;
            // 
            // dateTimePicker26
            // 
            this.dateTimePicker26.CustomFormat = "MM/dd/yyyy";
            this.dateTimePicker26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker26.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker26.Location = new System.Drawing.Point(765, 98);
            this.dateTimePicker26.Name = "dateTimePicker26";
            this.dateTimePicker26.Size = new System.Drawing.Size(85, 22);
            this.dateTimePicker26.TabIndex = 156;
            // 
            // dateTimePicker27
            // 
            this.dateTimePicker27.CustomFormat = "MM/dd/yyyy";
            this.dateTimePicker27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker27.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker27.Location = new System.Drawing.Point(649, 98);
            this.dateTimePicker27.Name = "dateTimePicker27";
            this.dateTimePicker27.Size = new System.Drawing.Size(85, 22);
            this.dateTimePicker27.TabIndex = 155;
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "Permanent",
            "Contractual",
            "Part Time",
            "Probationary"});
            this.comboBox4.Location = new System.Drawing.Point(871, 73);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(121, 21);
            this.comboBox4.TabIndex = 154;
            // 
            // dateTimePicker22
            // 
            this.dateTimePicker22.CustomFormat = "MM/dd/yyyy";
            this.dateTimePicker22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker22.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker22.Location = new System.Drawing.Point(765, 72);
            this.dateTimePicker22.Name = "dateTimePicker22";
            this.dateTimePicker22.Size = new System.Drawing.Size(85, 22);
            this.dateTimePicker22.TabIndex = 153;
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label95.Location = new System.Drawing.Point(740, 74);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(19, 16);
            this.label95.TabIndex = 152;
            this.label95.Text = "to";
            // 
            // dateTimePicker23
            // 
            this.dateTimePicker23.CustomFormat = "MM/dd/yyyy";
            this.dateTimePicker23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker23.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker23.Location = new System.Drawing.Point(649, 72);
            this.dateTimePicker23.Name = "dateTimePicker23";
            this.dateTimePicker23.Size = new System.Drawing.Size(85, 22);
            this.dateTimePicker23.TabIndex = 151;
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "Permanent",
            "Contractual",
            "Part Time",
            "Probationary"});
            this.comboBox3.Location = new System.Drawing.Point(871, 45);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(121, 21);
            this.comboBox3.TabIndex = 150;
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label94.Location = new System.Drawing.Point(884, 16);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(56, 18);
            this.label94.TabIndex = 149;
            this.label94.Text = "Status";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label91.Location = new System.Drawing.Point(646, 16);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(122, 18);
            this.label91.TabIndex = 148;
            this.label91.Text = "Inclusive Dates";
            // 
            // dateTimePicker18
            // 
            this.dateTimePicker18.CustomFormat = "MM/dd/yyyy";
            this.dateTimePicker18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker18.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker18.Location = new System.Drawing.Point(765, 44);
            this.dateTimePicker18.Name = "dateTimePicker18";
            this.dateTimePicker18.Size = new System.Drawing.Size(85, 22);
            this.dateTimePicker18.TabIndex = 147;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label90.Location = new System.Drawing.Point(740, 46);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(19, 16);
            this.label90.TabIndex = 124;
            this.label90.Text = "to";
            // 
            // textBox73
            // 
            this.textBox73.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox73.Location = new System.Drawing.Point(499, 152);
            this.textBox73.Multiline = true;
            this.textBox73.Name = "textBox73";
            this.textBox73.Size = new System.Drawing.Size(144, 20);
            this.textBox73.TabIndex = 146;
            // 
            // dateTimePicker20
            // 
            this.dateTimePicker20.CustomFormat = "MM/dd/yyyy";
            this.dateTimePicker20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker20.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker20.Location = new System.Drawing.Point(649, 44);
            this.dateTimePicker20.Name = "dateTimePicker20";
            this.dateTimePicker20.Size = new System.Drawing.Size(85, 22);
            this.dateTimePicker20.TabIndex = 123;
            // 
            // textBox74
            // 
            this.textBox74.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox74.Location = new System.Drawing.Point(499, 126);
            this.textBox74.Multiline = true;
            this.textBox74.Name = "textBox74";
            this.textBox74.Size = new System.Drawing.Size(144, 20);
            this.textBox74.TabIndex = 145;
            // 
            // textBox75
            // 
            this.textBox75.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox75.Location = new System.Drawing.Point(499, 100);
            this.textBox75.Multiline = true;
            this.textBox75.Name = "textBox75";
            this.textBox75.Size = new System.Drawing.Size(144, 20);
            this.textBox75.TabIndex = 144;
            // 
            // textBox76
            // 
            this.textBox76.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox76.Location = new System.Drawing.Point(499, 74);
            this.textBox76.Multiline = true;
            this.textBox76.Name = "textBox76";
            this.textBox76.Size = new System.Drawing.Size(144, 20);
            this.textBox76.TabIndex = 143;
            // 
            // textBox77
            // 
            this.textBox77.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox77.Location = new System.Drawing.Point(499, 46);
            this.textBox77.Multiline = true;
            this.textBox77.Name = "textBox77";
            this.textBox77.Size = new System.Drawing.Size(144, 20);
            this.textBox77.TabIndex = 142;
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label89.Location = new System.Drawing.Point(502, 16);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(70, 18);
            this.label89.TabIndex = 141;
            this.label89.Text = "Position";
            // 
            // textBox60
            // 
            this.textBox60.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox60.Location = new System.Drawing.Point(256, 152);
            this.textBox60.Multiline = true;
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(235, 20);
            this.textBox60.TabIndex = 140;
            // 
            // textBox62
            // 
            this.textBox62.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox62.Location = new System.Drawing.Point(256, 126);
            this.textBox62.Multiline = true;
            this.textBox62.Name = "textBox62";
            this.textBox62.Size = new System.Drawing.Size(235, 20);
            this.textBox62.TabIndex = 139;
            // 
            // textBox64
            // 
            this.textBox64.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox64.Location = new System.Drawing.Point(256, 100);
            this.textBox64.Multiline = true;
            this.textBox64.Name = "textBox64";
            this.textBox64.Size = new System.Drawing.Size(235, 20);
            this.textBox64.TabIndex = 138;
            // 
            // textBox66
            // 
            this.textBox66.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox66.Location = new System.Drawing.Point(256, 74);
            this.textBox66.Multiline = true;
            this.textBox66.Name = "textBox66";
            this.textBox66.Size = new System.Drawing.Size(235, 20);
            this.textBox66.TabIndex = 137;
            // 
            // textBox72
            // 
            this.textBox72.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox72.Location = new System.Drawing.Point(256, 46);
            this.textBox72.Multiline = true;
            this.textBox72.Name = "textBox72";
            this.textBox72.Size = new System.Drawing.Size(235, 20);
            this.textBox72.TabIndex = 136;
            // 
            // textBox70
            // 
            this.textBox70.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox70.Location = new System.Drawing.Point(12, 152);
            this.textBox70.Multiline = true;
            this.textBox70.Name = "textBox70";
            this.textBox70.Size = new System.Drawing.Size(235, 20);
            this.textBox70.TabIndex = 135;
            // 
            // textBox71
            // 
            this.textBox71.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox71.Location = new System.Drawing.Point(12, 126);
            this.textBox71.Multiline = true;
            this.textBox71.Name = "textBox71";
            this.textBox71.Size = new System.Drawing.Size(235, 20);
            this.textBox71.TabIndex = 134;
            // 
            // textBox69
            // 
            this.textBox69.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox69.Location = new System.Drawing.Point(12, 100);
            this.textBox69.Multiline = true;
            this.textBox69.Name = "textBox69";
            this.textBox69.Size = new System.Drawing.Size(235, 20);
            this.textBox69.TabIndex = 133;
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label92.Location = new System.Drawing.Point(259, 16);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(69, 18);
            this.label92.TabIndex = 125;
            this.label92.Text = "Address";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label93.Location = new System.Drawing.Point(9, 16);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(128, 18);
            this.label93.TabIndex = 124;
            this.label93.Text = "Company Name";
            // 
            // textBox67
            // 
            this.textBox67.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox67.Location = new System.Drawing.Point(12, 74);
            this.textBox67.Multiline = true;
            this.textBox67.Name = "textBox67";
            this.textBox67.Size = new System.Drawing.Size(235, 20);
            this.textBox67.TabIndex = 106;
            // 
            // textBox68
            // 
            this.textBox68.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox68.Location = new System.Drawing.Point(12, 46);
            this.textBox68.Multiline = true;
            this.textBox68.Name = "textBox68";
            this.textBox68.Size = new System.Drawing.Size(235, 20);
            this.textBox68.TabIndex = 80;
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label103.Location = new System.Drawing.Point(19, 428);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(103, 18);
            this.label103.TabIndex = 109;
            this.label103.Text = "PAG-IBIG NO.";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label96.Location = new System.Drawing.Point(10, 2174);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(171, 18);
            this.label96.TabIndex = 124;
            this.label96.Text = "WORK EXPERIENCE";
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.label85);
            this.groupBox20.Controls.Add(this.dateTimePicker15);
            this.groupBox20.Controls.Add(this.dateTimePicker16);
            this.groupBox20.Controls.Add(this.label84);
            this.groupBox20.Controls.Add(this.label83);
            this.groupBox20.Controls.Add(this.textBox57);
            this.groupBox20.Controls.Add(this.textBox56);
            this.groupBox20.Controls.Add(this.label82);
            this.groupBox20.Controls.Add(this.label88);
            this.groupBox20.Controls.Add(this.textBox59);
            this.groupBox20.Controls.Add(this.dateTimePicker19);
            this.groupBox20.Controls.Add(this.textBox61);
            this.groupBox20.Controls.Add(this.textBox63);
            this.groupBox20.Controls.Add(this.label86);
            this.groupBox20.Controls.Add(this.dateTimePicker21);
            this.groupBox20.Controls.Add(this.textBox65);
            this.groupBox20.Controls.Add(this.label87);
            this.groupBox20.Location = new System.Drawing.Point(13, 2054);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(1011, 108);
            this.groupBox20.TabIndex = 123;
            this.groupBox20.TabStop = false;
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label85.Location = new System.Drawing.Point(884, 16);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(83, 18);
            this.label85.TabIndex = 132;
            this.label85.Text = "Valid Until";
            // 
            // dateTimePicker15
            // 
            this.dateTimePicker15.CustomFormat = "MM/dd/yyyy";
            this.dateTimePicker15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker15.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker15.Location = new System.Drawing.Point(887, 70);
            this.dateTimePicker15.Name = "dateTimePicker15";
            this.dateTimePicker15.Size = new System.Drawing.Size(100, 22);
            this.dateTimePicker15.TabIndex = 131;
            // 
            // dateTimePicker16
            // 
            this.dateTimePicker16.CustomFormat = "MM/dd/yyyy";
            this.dateTimePicker16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker16.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker16.Location = new System.Drawing.Point(887, 44);
            this.dateTimePicker16.Name = "dateTimePicker16";
            this.dateTimePicker16.Size = new System.Drawing.Size(100, 22);
            this.dateTimePicker16.TabIndex = 130;
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label84.Location = new System.Drawing.Point(603, 16);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(257, 18);
            this.label84.TabIndex = 129;
            this.label84.Text = "PROFESSIONAL LICENSE(PRC)";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label83.Location = new System.Drawing.Point(438, 16);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(143, 18);
            this.label83.TabIndex = 128;
            this.label83.Text = "Date of Expiration";
            // 
            // textBox57
            // 
            this.textBox57.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox57.Location = new System.Drawing.Point(308, 74);
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(102, 22);
            this.textBox57.TabIndex = 127;
            // 
            // textBox56
            // 
            this.textBox56.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox56.Location = new System.Drawing.Point(308, 46);
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(102, 22);
            this.textBox56.TabIndex = 126;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label82.Location = new System.Drawing.Point(305, 16);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(56, 18);
            this.label82.TabIndex = 125;
            this.label82.Text = "Rating";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label88.Location = new System.Drawing.Point(9, 16);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(209, 18);
            this.label88.TabIndex = 124;
            this.label88.Text = "ELEGIBILITY(Civil Service)";
            // 
            // textBox59
            // 
            this.textBox59.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox59.Location = new System.Drawing.Point(606, 72);
            this.textBox59.Multiline = true;
            this.textBox59.Name = "textBox59";
            this.textBox59.Size = new System.Drawing.Size(228, 20);
            this.textBox59.TabIndex = 117;
            // 
            // dateTimePicker19
            // 
            this.dateTimePicker19.CustomFormat = "MM/dd/yyyy";
            this.dateTimePicker19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker19.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker19.Location = new System.Drawing.Point(441, 70);
            this.dateTimePicker19.Name = "dateTimePicker19";
            this.dateTimePicker19.Size = new System.Drawing.Size(100, 22);
            this.dateTimePicker19.TabIndex = 113;
            // 
            // textBox61
            // 
            this.textBox61.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox61.Location = new System.Drawing.Point(606, 46);
            this.textBox61.Multiline = true;
            this.textBox61.Name = "textBox61";
            this.textBox61.Size = new System.Drawing.Size(228, 20);
            this.textBox61.TabIndex = 112;
            // 
            // textBox63
            // 
            this.textBox63.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox63.Location = new System.Drawing.Point(35, 74);
            this.textBox63.Multiline = true;
            this.textBox63.Name = "textBox63";
            this.textBox63.Size = new System.Drawing.Size(248, 20);
            this.textBox63.TabIndex = 106;
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label86.Location = new System.Drawing.Point(9, 75);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(20, 18);
            this.label86.TabIndex = 107;
            this.label86.Text = "2.";
            // 
            // dateTimePicker21
            // 
            this.dateTimePicker21.CustomFormat = "MM/dd/yyyy";
            this.dateTimePicker21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker21.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker21.Location = new System.Drawing.Point(441, 44);
            this.dateTimePicker21.Name = "dateTimePicker21";
            this.dateTimePicker21.Size = new System.Drawing.Size(100, 22);
            this.dateTimePicker21.TabIndex = 92;
            // 
            // textBox65
            // 
            this.textBox65.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox65.Location = new System.Drawing.Point(35, 46);
            this.textBox65.Multiline = true;
            this.textBox65.Name = "textBox65";
            this.textBox65.Size = new System.Drawing.Size(248, 20);
            this.textBox65.TabIndex = 80;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label87.Location = new System.Drawing.Point(9, 47);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(20, 18);
            this.label87.TabIndex = 81;
            this.label87.Text = "1.";
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label104.Location = new System.Drawing.Point(19, 398);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(126, 18);
            this.label104.TabIndex = 107;
            this.label104.Text = "GSIS/SSS ID NO.";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label81.Location = new System.Drawing.Point(10, 2023);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(311, 18);
            this.label81.TabIndex = 88;
            this.label81.Text = "ELEGIBILITY/PROFESSIONAL LICENSE";
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.label73);
            this.groupBox18.Controls.Add(this.label71);
            this.groupBox18.Controls.Add(this.label70);
            this.groupBox18.Controls.Add(this.groupBox19);
            this.groupBox18.Controls.Add(this.label74);
            this.groupBox18.Controls.Add(this.label75);
            this.groupBox18.Location = new System.Drawing.Point(13, 1871);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(1011, 140);
            this.groupBox18.TabIndex = 87;
            this.groupBox18.TabStop = false;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label73.Location = new System.Drawing.Point(563, 12);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(180, 16);
            this.label73.TabIndex = 86;
            this.label73.Text = "TRAINING ISNTITUTION";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label71.Location = new System.Drawing.Point(307, 12);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(87, 16);
            this.label71.TabIndex = 85;
            this.label71.Text = "DURATION";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.Location = new System.Drawing.Point(9, 12);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(247, 16);
            this.label70.TabIndex = 84;
            this.label70.Text = "TRAINING/VOCATIONAL COURSE";
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.textBox54);
            this.groupBox19.Controls.Add(this.dateTimePicker13);
            this.groupBox19.Controls.Add(this.label80);
            this.groupBox19.Controls.Add(this.textBox55);
            this.groupBox19.Controls.Add(this.dateTimePicker14);
            this.groupBox19.Controls.Add(this.textBox52);
            this.groupBox19.Controls.Add(this.dateTimePicker11);
            this.groupBox19.Controls.Add(this.label76);
            this.groupBox19.Controls.Add(this.textBox53);
            this.groupBox19.Controls.Add(this.dateTimePicker12);
            this.groupBox19.Controls.Add(this.textBox51);
            this.groupBox19.Controls.Add(this.dateTimePicker10);
            this.groupBox19.Controls.Add(this.label72);
            this.groupBox19.Controls.Add(this.textBox50);
            this.groupBox19.Controls.Add(this.label79);
            this.groupBox19.Controls.Add(this.textBox48);
            this.groupBox19.Controls.Add(this.label78);
            this.groupBox19.Controls.Add(this.textBox49);
            this.groupBox19.Controls.Add(this.dateTimePicker17);
            this.groupBox19.Controls.Add(this.textBox58);
            this.groupBox19.Controls.Add(this.label77);
            this.groupBox19.Location = new System.Drawing.Point(0, 37);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(1011, 103);
            this.groupBox19.TabIndex = 80;
            this.groupBox19.TabStop = false;
            // 
            // textBox54
            // 
            this.textBox54.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox54.Location = new System.Drawing.Point(566, 67);
            this.textBox54.Multiline = true;
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(228, 20);
            this.textBox54.TabIndex = 122;
            // 
            // dateTimePicker13
            // 
            this.dateTimePicker13.CustomFormat = "MM/dd/yyyy";
            this.dateTimePicker13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker13.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker13.Location = new System.Drawing.Point(441, 65);
            this.dateTimePicker13.Name = "dateTimePicker13";
            this.dateTimePicker13.Size = new System.Drawing.Size(100, 22);
            this.dateTimePicker13.TabIndex = 121;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label80.Location = new System.Drawing.Point(416, 68);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(19, 16);
            this.label80.TabIndex = 120;
            this.label80.Text = "to";
            // 
            // textBox55
            // 
            this.textBox55.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox55.Location = new System.Drawing.Point(812, 67);
            this.textBox55.Multiline = true;
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(193, 20);
            this.textBox55.TabIndex = 119;
            // 
            // dateTimePicker14
            // 
            this.dateTimePicker14.CustomFormat = "MM/dd/yyyy";
            this.dateTimePicker14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker14.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker14.Location = new System.Drawing.Point(310, 65);
            this.dateTimePicker14.Name = "dateTimePicker14";
            this.dateTimePicker14.Size = new System.Drawing.Size(100, 22);
            this.dateTimePicker14.TabIndex = 118;
            // 
            // textBox52
            // 
            this.textBox52.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox52.Location = new System.Drawing.Point(566, 41);
            this.textBox52.Multiline = true;
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(228, 20);
            this.textBox52.TabIndex = 117;
            // 
            // dateTimePicker11
            // 
            this.dateTimePicker11.CustomFormat = "MM/dd/yyyy";
            this.dateTimePicker11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker11.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker11.Location = new System.Drawing.Point(441, 39);
            this.dateTimePicker11.Name = "dateTimePicker11";
            this.dateTimePicker11.Size = new System.Drawing.Size(100, 22);
            this.dateTimePicker11.TabIndex = 116;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label76.Location = new System.Drawing.Point(416, 42);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(19, 16);
            this.label76.TabIndex = 115;
            this.label76.Text = "to";
            // 
            // textBox53
            // 
            this.textBox53.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox53.Location = new System.Drawing.Point(812, 41);
            this.textBox53.Multiline = true;
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(193, 20);
            this.textBox53.TabIndex = 114;
            // 
            // dateTimePicker12
            // 
            this.dateTimePicker12.CustomFormat = "MM/dd/yyyy";
            this.dateTimePicker12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker12.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker12.Location = new System.Drawing.Point(310, 39);
            this.dateTimePicker12.Name = "dateTimePicker12";
            this.dateTimePicker12.Size = new System.Drawing.Size(100, 22);
            this.dateTimePicker12.TabIndex = 113;
            // 
            // textBox51
            // 
            this.textBox51.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox51.Location = new System.Drawing.Point(566, 15);
            this.textBox51.Multiline = true;
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(228, 20);
            this.textBox51.TabIndex = 112;
            // 
            // dateTimePicker10
            // 
            this.dateTimePicker10.CustomFormat = "MM/dd/yyyy";
            this.dateTimePicker10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker10.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker10.Location = new System.Drawing.Point(441, 13);
            this.dateTimePicker10.Name = "dateTimePicker10";
            this.dateTimePicker10.Size = new System.Drawing.Size(100, 22);
            this.dateTimePicker10.TabIndex = 111;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label72.Location = new System.Drawing.Point(416, 16);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(19, 16);
            this.label72.TabIndex = 110;
            this.label72.Text = "to";
            // 
            // textBox50
            // 
            this.textBox50.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox50.Location = new System.Drawing.Point(35, 67);
            this.textBox50.Multiline = true;
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(248, 20);
            this.textBox50.TabIndex = 108;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label79.Location = new System.Drawing.Point(9, 68);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(20, 18);
            this.label79.TabIndex = 109;
            this.label79.Text = "3.";
            // 
            // textBox48
            // 
            this.textBox48.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox48.Location = new System.Drawing.Point(35, 41);
            this.textBox48.Multiline = true;
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(248, 20);
            this.textBox48.TabIndex = 106;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label78.Location = new System.Drawing.Point(9, 42);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(20, 18);
            this.label78.TabIndex = 107;
            this.label78.Text = "2.";
            // 
            // textBox49
            // 
            this.textBox49.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox49.Location = new System.Drawing.Point(812, 15);
            this.textBox49.Multiline = true;
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(193, 20);
            this.textBox49.TabIndex = 105;
            // 
            // dateTimePicker17
            // 
            this.dateTimePicker17.CustomFormat = "MM/dd/yyyy";
            this.dateTimePicker17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker17.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker17.Location = new System.Drawing.Point(310, 13);
            this.dateTimePicker17.Name = "dateTimePicker17";
            this.dateTimePicker17.Size = new System.Drawing.Size(100, 22);
            this.dateTimePicker17.TabIndex = 92;
            // 
            // textBox58
            // 
            this.textBox58.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox58.Location = new System.Drawing.Point(35, 15);
            this.textBox58.Multiline = true;
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(248, 20);
            this.textBox58.TabIndex = 80;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label77.Location = new System.Drawing.Point(9, 16);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(20, 18);
            this.label77.TabIndex = 81;
            this.label77.Text = "1.";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label74.Location = new System.Drawing.Point(809, 9);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(196, 16);
            this.label74.TabIndex = 87;
            this.label74.Text = "CERTIFICATES RECEIVED";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label75.Location = new System.Drawing.Point(829, 25);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(152, 13);
            this.label75.TabIndex = 104;
            this.label75.Text = "(NC I, NC II, NC III, NC IV, etc)";
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label105.Location = new System.Drawing.Point(16, 368);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(31, 18);
            this.label105.TabIndex = 81;
            this.label105.Text = "TIN";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.Location = new System.Drawing.Point(406, 2045);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(355, 18);
            this.label69.TabIndex = 87;
            this.label69.Text = "(Include courses takens as part of college education)";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.Location = new System.Drawing.Point(10, 1850);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(392, 18);
            this.label68.TabIndex = 86;
            this.label68.Text = "TECHNICAL/VOCATIONAL AND OTHER TRAINING";
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.label57);
            this.groupBox16.Controls.Add(this.label58);
            this.groupBox16.Controls.Add(this.label59);
            this.groupBox16.Controls.Add(this.label60);
            this.groupBox16.Controls.Add(this.label64);
            this.groupBox16.Location = new System.Drawing.Point(13, 1608);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(1011, 230);
            this.groupBox16.TabIndex = 85;
            this.groupBox16.TabStop = false;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.Location = new System.Drawing.Point(8, 9);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(64, 20);
            this.label57.TabIndex = 84;
            this.label57.Text = "School";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.Location = new System.Drawing.Point(306, 9);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(66, 20);
            this.label58.TabIndex = 83;
            this.label58.Text = "Course";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.Location = new System.Drawing.Point(484, 9);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(138, 20);
            this.label59.TabIndex = 82;
            this.label59.Text = "Year Graduated";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.Location = new System.Drawing.Point(868, 10);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(137, 18);
            this.label60.TabIndex = 81;
            this.label60.Text = "Awards Received";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.Location = new System.Drawing.Point(645, 9);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(149, 20);
            this.label64.TabIndex = 86;
            this.label64.Text = "If undergraduate,";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(10, 1587);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(246, 18);
            this.label56.TabIndex = 59;
            this.label56.Text = "EDUCATIONAL BACKGROUND";
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.label55);
            this.groupBox14.Controls.Add(this.label54);
            this.groupBox14.Controls.Add(this.label53);
            this.groupBox14.Controls.Add(this.label48);
            this.groupBox14.Controls.Add(this.groupBox15);
            this.groupBox14.Controls.Add(this.label49);
            this.groupBox14.Location = new System.Drawing.Point(13, 1409);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(1011, 166);
            this.groupBox14.TabIndex = 57;
            this.groupBox14.TabStop = false;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(306, 14);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(59, 20);
            this.label55.TabIndex = 84;
            this.label55.Text = "READ";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(501, 14);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(66, 20);
            this.label54.TabIndex = 83;
            this.label54.Text = "WRITE";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(710, 14);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(67, 20);
            this.label53.TabIndex = 82;
            this.label53.Text = "SPEAK";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(874, 14);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(131, 20);
            this.label48.TabIndex = 81;
            this.label48.Text = "UNDERSTAND";
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.textBox31);
            this.groupBox15.Controls.Add(this.checkBox26);
            this.groupBox15.Controls.Add(this.label51);
            this.groupBox15.Controls.Add(this.checkBox27);
            this.groupBox15.Controls.Add(this.checkBox28);
            this.groupBox15.Controls.Add(this.checkBox29);
            this.groupBox15.Controls.Add(this.checkBox22);
            this.groupBox15.Controls.Add(this.checkBox23);
            this.groupBox15.Controls.Add(this.checkBox24);
            this.groupBox15.Controls.Add(this.checkBox25);
            this.groupBox15.Controls.Add(this.label50);
            this.groupBox15.Controls.Add(this.checkBox21);
            this.groupBox15.Controls.Add(this.checkBox20);
            this.groupBox15.Controls.Add(this.checkBox19);
            this.groupBox15.Controls.Add(this.checkBox18);
            this.groupBox15.Controls.Add(this.label52);
            this.groupBox15.Location = new System.Drawing.Point(0, 37);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(1011, 129);
            this.groupBox15.TabIndex = 80;
            this.groupBox15.TabStop = false;
            // 
            // textBox31
            // 
            this.textBox31.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox31.Location = new System.Drawing.Point(65, 82);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(218, 24);
            this.textBox31.TabIndex = 80;
            // 
            // checkBox26
            // 
            this.checkBox26.AutoSize = true;
            this.checkBox26.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox26.Location = new System.Drawing.Point(878, 82);
            this.checkBox26.Name = "checkBox26";
            this.checkBox26.Size = new System.Drawing.Size(52, 22);
            this.checkBox26.TabIndex = 88;
            this.checkBox26.Text = "Yes";
            this.checkBox26.UseVisualStyleBackColor = true;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(8, 84);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(61, 20);
            this.label51.TabIndex = 81;
            this.label51.Text = "Others:";
            // 
            // checkBox27
            // 
            this.checkBox27.AutoSize = true;
            this.checkBox27.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox27.Location = new System.Drawing.Point(714, 82);
            this.checkBox27.Name = "checkBox27";
            this.checkBox27.Size = new System.Drawing.Size(52, 22);
            this.checkBox27.TabIndex = 87;
            this.checkBox27.Text = "Yes";
            this.checkBox27.UseVisualStyleBackColor = true;
            // 
            // checkBox28
            // 
            this.checkBox28.AutoSize = true;
            this.checkBox28.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox28.Location = new System.Drawing.Point(505, 80);
            this.checkBox28.Name = "checkBox28";
            this.checkBox28.Size = new System.Drawing.Size(52, 22);
            this.checkBox28.TabIndex = 86;
            this.checkBox28.Text = "Yes";
            this.checkBox28.UseVisualStyleBackColor = true;
            // 
            // checkBox29
            // 
            this.checkBox29.AutoSize = true;
            this.checkBox29.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox29.Location = new System.Drawing.Point(310, 82);
            this.checkBox29.Name = "checkBox29";
            this.checkBox29.Size = new System.Drawing.Size(52, 22);
            this.checkBox29.TabIndex = 84;
            this.checkBox29.Text = "Yes";
            this.checkBox29.UseVisualStyleBackColor = true;
            // 
            // checkBox22
            // 
            this.checkBox22.AutoSize = true;
            this.checkBox22.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox22.Location = new System.Drawing.Point(878, 45);
            this.checkBox22.Name = "checkBox22";
            this.checkBox22.Size = new System.Drawing.Size(52, 22);
            this.checkBox22.TabIndex = 83;
            this.checkBox22.Text = "Yes";
            this.checkBox22.UseVisualStyleBackColor = true;
            // 
            // checkBox23
            // 
            this.checkBox23.AutoSize = true;
            this.checkBox23.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox23.Location = new System.Drawing.Point(714, 45);
            this.checkBox23.Name = "checkBox23";
            this.checkBox23.Size = new System.Drawing.Size(52, 22);
            this.checkBox23.TabIndex = 82;
            this.checkBox23.Text = "Yes";
            this.checkBox23.UseVisualStyleBackColor = true;
            // 
            // checkBox24
            // 
            this.checkBox24.AutoSize = true;
            this.checkBox24.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox24.Location = new System.Drawing.Point(505, 43);
            this.checkBox24.Name = "checkBox24";
            this.checkBox24.Size = new System.Drawing.Size(52, 22);
            this.checkBox24.TabIndex = 81;
            this.checkBox24.Text = "Yes";
            this.checkBox24.UseVisualStyleBackColor = true;
            // 
            // checkBox25
            // 
            this.checkBox25.AutoSize = true;
            this.checkBox25.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox25.Location = new System.Drawing.Point(310, 45);
            this.checkBox25.Name = "checkBox25";
            this.checkBox25.Size = new System.Drawing.Size(52, 22);
            this.checkBox25.TabIndex = 79;
            this.checkBox25.Text = "Yes";
            this.checkBox25.UseVisualStyleBackColor = true;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(8, 45);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(58, 20);
            this.label50.TabIndex = 80;
            this.label50.Text = "Filipino";
            // 
            // checkBox21
            // 
            this.checkBox21.AutoSize = true;
            this.checkBox21.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox21.Location = new System.Drawing.Point(878, 17);
            this.checkBox21.Name = "checkBox21";
            this.checkBox21.Size = new System.Drawing.Size(52, 22);
            this.checkBox21.TabIndex = 78;
            this.checkBox21.Text = "Yes";
            this.checkBox21.UseVisualStyleBackColor = true;
            // 
            // checkBox20
            // 
            this.checkBox20.AutoSize = true;
            this.checkBox20.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox20.Location = new System.Drawing.Point(714, 17);
            this.checkBox20.Name = "checkBox20";
            this.checkBox20.Size = new System.Drawing.Size(52, 22);
            this.checkBox20.TabIndex = 77;
            this.checkBox20.Text = "Yes";
            this.checkBox20.UseVisualStyleBackColor = true;
            // 
            // checkBox19
            // 
            this.checkBox19.AutoSize = true;
            this.checkBox19.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox19.Location = new System.Drawing.Point(505, 15);
            this.checkBox19.Name = "checkBox19";
            this.checkBox19.Size = new System.Drawing.Size(52, 22);
            this.checkBox19.TabIndex = 76;
            this.checkBox19.Text = "Yes";
            this.checkBox19.UseVisualStyleBackColor = true;
            // 
            // checkBox18
            // 
            this.checkBox18.AutoSize = true;
            this.checkBox18.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox18.Location = new System.Drawing.Point(310, 17);
            this.checkBox18.Name = "checkBox18";
            this.checkBox18.Size = new System.Drawing.Size(52, 22);
            this.checkBox18.TabIndex = 75;
            this.checkBox18.Text = "Yes";
            this.checkBox18.UseVisualStyleBackColor = true;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(8, 17);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(61, 20);
            this.label52.TabIndex = 75;
            this.label52.Text = "English";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(6, 16);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(151, 20);
            this.label49.TabIndex = 51;
            this.label49.Text = "(Check if applicable)";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(10, 1379);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(297, 18);
            this.label47.TabIndex = 58;
            this.label47.Text = "LANGUAGE / DIALECT PROFICIENCY";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.radioButton26);
            this.groupBox12.Controls.Add(this.radioButton25);
            this.groupBox12.Controls.Add(this.groupBox13);
            this.groupBox12.Controls.Add(this.label43);
            this.groupBox12.Controls.Add(this.label40);
            this.groupBox12.Controls.Add(this.textBox25);
            this.groupBox12.Controls.Add(this.label41);
            this.groupBox12.Controls.Add(this.textBox26);
            this.groupBox12.Controls.Add(this.label42);
            this.groupBox12.Controls.Add(this.textBox27);
            this.groupBox12.Controls.Add(this.label36);
            this.groupBox12.Controls.Add(this.textBox22);
            this.groupBox12.Controls.Add(this.label38);
            this.groupBox12.Controls.Add(this.textBox23);
            this.groupBox12.Controls.Add(this.label39);
            this.groupBox12.Controls.Add(this.textBox24);
            this.groupBox12.Controls.Add(this.label35);
            this.groupBox12.Controls.Add(this.textBox20);
            this.groupBox12.Controls.Add(this.label34);
            this.groupBox12.Controls.Add(this.textBox19);
            this.groupBox12.Controls.Add(this.label33);
            this.groupBox12.Controls.Add(this.label37);
            this.groupBox12.Controls.Add(this.textBox21);
            this.groupBox12.Location = new System.Drawing.Point(12, 1107);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(1011, 233);
            this.groupBox12.TabIndex = 57;
            this.groupBox12.TabStop = false;
            // 
            // radioButton26
            // 
            this.radioButton26.AutoSize = true;
            this.radioButton26.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.radioButton26.Location = new System.Drawing.Point(615, 47);
            this.radioButton26.Name = "radioButton26";
            this.radioButton26.Size = new System.Drawing.Size(213, 22);
            this.radioButton26.TabIndex = 76;
            this.radioButton26.TabStop = true;
            this.radioButton26.Text = "Overseas, specific countries";
            this.radioButton26.UseVisualStyleBackColor = true;
            // 
            // radioButton25
            // 
            this.radioButton25.AutoSize = true;
            this.radioButton25.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.radioButton25.Location = new System.Drawing.Point(328, 47);
            this.radioButton25.Name = "radioButton25";
            this.radioButton25.Size = new System.Drawing.Size(238, 22);
            this.radioButton25.TabIndex = 75;
            this.radioButton25.TabStop = true;
            this.radioButton25.Text = "Local, specific cities/municipality";
            this.radioButton25.UseVisualStyleBackColor = true;
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.textBox30);
            this.groupBox13.Controls.Add(this.label46);
            this.groupBox13.Controls.Add(this.textBox29);
            this.groupBox13.Controls.Add(this.label45);
            this.groupBox13.Controls.Add(this.textBox28);
            this.groupBox13.Controls.Add(this.label44);
            this.groupBox13.Location = new System.Drawing.Point(6, 178);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(877, 49);
            this.groupBox13.TabIndex = 74;
            this.groupBox13.TabStop = false;
            // 
            // textBox30
            // 
            this.textBox30.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox30.Location = new System.Drawing.Point(694, 15);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(164, 24);
            this.textBox30.TabIndex = 78;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(587, 17);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(94, 20);
            this.label46.TabIndex = 79;
            this.label46.Text = "Expiry Date:";
            // 
            // textBox29
            // 
            this.textBox29.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox29.Location = new System.Drawing.Point(418, 15);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(164, 24);
            this.textBox29.TabIndex = 76;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(312, 17);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(100, 20);
            this.label45.TabIndex = 77;
            this.label45.Text = "Passport No.";
            // 
            // textBox28
            // 
            this.textBox28.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox28.Location = new System.Drawing.Point(142, 15);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(164, 24);
            this.textBox28.TabIndex = 75;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(8, 17);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(128, 20);
            this.label44.TabIndex = 75;
            this.label44.Text = "Expected Salary:";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(506, 16);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(182, 20);
            this.label43.TabIndex = 72;
            this.label43.Text = "PREFERED LOCATION";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(593, 136);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(22, 20);
            this.label40.TabIndex = 71;
            this.label40.Text = "3.";
            // 
            // textBox25
            // 
            this.textBox25.Enabled = false;
            this.textBox25.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox25.Location = new System.Drawing.Point(615, 134);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(249, 24);
            this.textBox25.TabIndex = 70;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(593, 106);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(22, 20);
            this.label41.TabIndex = 69;
            this.label41.Text = "2.";
            // 
            // textBox26
            // 
            this.textBox26.Enabled = false;
            this.textBox26.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox26.Location = new System.Drawing.Point(615, 104);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(249, 24);
            this.textBox26.TabIndex = 68;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(593, 76);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(22, 20);
            this.label42.TabIndex = 67;
            this.label42.Text = "1.";
            // 
            // textBox27
            // 
            this.textBox27.Enabled = false;
            this.textBox27.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox27.Location = new System.Drawing.Point(615, 74);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(249, 24);
            this.textBox27.TabIndex = 66;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(306, 140);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(22, 20);
            this.label36.TabIndex = 65;
            this.label36.Text = "3.";
            // 
            // textBox22
            // 
            this.textBox22.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox22.Location = new System.Drawing.Point(328, 138);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(249, 24);
            this.textBox22.TabIndex = 64;
            this.textBox22.Leave += new System.EventHandler(this.textBox22_Leave);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(306, 110);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(22, 20);
            this.label38.TabIndex = 63;
            this.label38.Text = "2.";
            // 
            // textBox23
            // 
            this.textBox23.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox23.Location = new System.Drawing.Point(328, 108);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(249, 24);
            this.textBox23.TabIndex = 62;
            this.textBox23.Leave += new System.EventHandler(this.textBox23_Leave);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(306, 80);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(22, 20);
            this.label39.TabIndex = 61;
            this.label39.Text = "1.";
            // 
            // textBox24
            // 
            this.textBox24.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox24.Location = new System.Drawing.Point(328, 78);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(249, 24);
            this.textBox24.TabIndex = 60;
            this.textBox24.Leave += new System.EventHandler(this.textBox24_Leave);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(12, 140);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(22, 20);
            this.label35.TabIndex = 59;
            this.label35.Text = "3.";
            // 
            // textBox20
            // 
            this.textBox20.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox20.Location = new System.Drawing.Point(34, 138);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(249, 24);
            this.textBox20.TabIndex = 58;
            this.textBox20.Leave += new System.EventHandler(this.textBox20_Leave);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(12, 110);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(22, 20);
            this.label34.TabIndex = 57;
            this.label34.Text = "2.";
            // 
            // textBox19
            // 
            this.textBox19.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox19.Location = new System.Drawing.Point(34, 108);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(249, 24);
            this.textBox19.TabIndex = 56;
            this.textBox19.Leave += new System.EventHandler(this.textBox19_Leave);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(12, 80);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(22, 20);
            this.label33.TabIndex = 55;
            this.label33.Text = "1.";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(6, 16);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(206, 20);
            this.label37.TabIndex = 54;
            this.label37.Text = "PREFERED OCCUPATION";
            // 
            // textBox21
            // 
            this.textBox21.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox21.Location = new System.Drawing.Point(34, 78);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(249, 24);
            this.textBox21.TabIndex = 51;
            this.textBox21.Leave += new System.EventHandler(this.textBox21_Leave);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(9, 1077);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(159, 18);
            this.label32.TabIndex = 49;
            this.label32.Text = "JOB PREFERENCE";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.groupBox11);
            this.groupBox8.Controls.Add(this.groupBox10);
            this.groupBox8.Controls.Add(this.groupBox9);
            this.groupBox8.Location = new System.Drawing.Point(6, 900);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(1011, 164);
            this.groupBox8.TabIndex = 47;
            this.groupBox8.TabStop = false;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.label30);
            this.groupBox11.Controls.Add(this.textBox18);
            this.groupBox11.Controls.Add(this.radioButton12);
            this.groupBox11.Controls.Add(this.radioButton13);
            this.groupBox11.Controls.Add(this.label31);
            this.groupBox11.Location = new System.Drawing.Point(6, 106);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(883, 49);
            this.groupBox11.TabIndex = 56;
            this.groupBox11.TabStop = false;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(418, 16);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(181, 20);
            this.label30.TabIndex = 54;
            this.label30.Text = "If yes, Household ID No.";
            // 
            // textBox18
            // 
            this.textBox18.Enabled = false;
            this.textBox18.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox18.Location = new System.Drawing.Point(672, 14);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(192, 24);
            this.textBox18.TabIndex = 51;
            // 
            // radioButton12
            // 
            this.radioButton12.AutoSize = true;
            this.radioButton12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton12.Location = new System.Drawing.Point(346, 16);
            this.radioButton12.Name = "radioButton12";
            this.radioButton12.Size = new System.Drawing.Size(47, 24);
            this.radioButton12.TabIndex = 53;
            this.radioButton12.TabStop = true;
            this.radioButton12.Text = "No";
            this.radioButton12.UseVisualStyleBackColor = true;
            this.radioButton12.CheckedChanged += new System.EventHandler(this.radioButton12_CheckedChanged);
            // 
            // radioButton13
            // 
            this.radioButton13.AutoSize = true;
            this.radioButton13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton13.Location = new System.Drawing.Point(285, 16);
            this.radioButton13.Name = "radioButton13";
            this.radioButton13.Size = new System.Drawing.Size(55, 24);
            this.radioButton13.TabIndex = 52;
            this.radioButton13.TabStop = true;
            this.radioButton13.Text = "Yes";
            this.radioButton13.UseVisualStyleBackColor = true;
            this.radioButton13.CheckedChanged += new System.EventHandler(this.radioButton13_CheckedChanged);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(6, 16);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(196, 20);
            this.label31.TabIndex = 51;
            this.label31.Text = "Are you a 4Ps beneficiary?";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.label28);
            this.groupBox10.Controls.Add(this.textBox17);
            this.groupBox10.Controls.Add(this.radioButton10);
            this.groupBox10.Controls.Add(this.radioButton11);
            this.groupBox10.Controls.Add(this.label29);
            this.groupBox10.Location = new System.Drawing.Point(6, 57);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(883, 49);
            this.groupBox10.TabIndex = 55;
            this.groupBox10.TabStop = false;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(418, 16);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(96, 20);
            this.label28.TabIndex = 54;
            this.label28.Text = "If no, when?";
            // 
            // textBox17
            // 
            this.textBox17.Enabled = false;
            this.textBox17.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox17.Location = new System.Drawing.Point(672, 14);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(192, 24);
            this.textBox17.TabIndex = 51;
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton10.Location = new System.Drawing.Point(346, 16);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(47, 24);
            this.radioButton10.TabIndex = 53;
            this.radioButton10.TabStop = true;
            this.radioButton10.Text = "No";
            this.radioButton10.UseVisualStyleBackColor = true;
            this.radioButton10.CheckedChanged += new System.EventHandler(this.radioButton10_CheckedChanged);
            // 
            // radioButton11
            // 
            this.radioButton11.AutoSize = true;
            this.radioButton11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton11.Location = new System.Drawing.Point(285, 16);
            this.radioButton11.Name = "radioButton11";
            this.radioButton11.Size = new System.Drawing.Size(55, 24);
            this.radioButton11.TabIndex = 52;
            this.radioButton11.TabStop = true;
            this.radioButton11.Text = "Yes";
            this.radioButton11.UseVisualStyleBackColor = true;
            this.radioButton11.CheckedChanged += new System.EventHandler(this.radioButton11_CheckedChanged);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(6, 16);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(205, 20);
            this.label29.TabIndex = 51;
            this.label29.Text = "Wiiling to work immediately?";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.label27);
            this.groupBox9.Controls.Add(this.textBox16);
            this.groupBox9.Controls.Add(this.radioButton9);
            this.groupBox9.Controls.Add(this.radioButton8);
            this.groupBox9.Controls.Add(this.label25);
            this.groupBox9.Location = new System.Drawing.Point(6, 8);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(883, 49);
            this.groupBox9.TabIndex = 4;
            this.groupBox9.TabStop = false;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(417, 21);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(237, 15);
            this.label27.TabIndex = 54;
            this.label27.Text = "How long have you been looking for work?";
            // 
            // textBox16
            // 
            this.textBox16.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox16.Location = new System.Drawing.Point(672, 14);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(192, 24);
            this.textBox16.TabIndex = 51;
            // 
            // radioButton9
            // 
            this.radioButton9.AutoSize = true;
            this.radioButton9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton9.Location = new System.Drawing.Point(346, 16);
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.Size = new System.Drawing.Size(47, 24);
            this.radioButton9.TabIndex = 53;
            this.radioButton9.TabStop = true;
            this.radioButton9.Text = "No";
            this.radioButton9.UseVisualStyleBackColor = true;
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton8.Location = new System.Drawing.Point(285, 16);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(55, 24);
            this.radioButton8.TabIndex = 52;
            this.radioButton8.TabStop = true;
            this.radioButton8.Text = "Yes";
            this.radioButton8.UseVisualStyleBackColor = true;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(6, 16);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(241, 20);
            this.label25.TabIndex = 51;
            this.label25.Text = "Are you actively looking for work?";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(8, 619);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(195, 18);
            this.label22.TabIndex = 47;
            this.label22.Text = "Employment Status/Type";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.radioButton15);
            this.groupBox5.Controls.Add(this.radioButton14);
            this.groupBox5.Controls.Add(this.groupBox7);
            this.groupBox5.Controls.Add(this.groupBox6);
            this.groupBox5.Location = new System.Drawing.Point(6, 640);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(1011, 245);
            this.groupBox5.TabIndex = 46;
            this.groupBox5.TabStop = false;
            // 
            // radioButton15
            // 
            this.radioButton15.AutoSize = true;
            this.radioButton15.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.radioButton15.Location = new System.Drawing.Point(431, 18);
            this.radioButton15.Name = "radioButton15";
            this.radioButton15.Size = new System.Drawing.Size(109, 22);
            this.radioButton15.TabIndex = 6;
            this.radioButton15.TabStop = true;
            this.radioButton15.Text = "Unemployed";
            this.radioButton15.UseVisualStyleBackColor = true;
            this.radioButton15.CheckedChanged += new System.EventHandler(this.radioButton15_CheckedChanged);
            // 
            // radioButton14
            // 
            this.radioButton14.AutoSize = true;
            this.radioButton14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.radioButton14.Location = new System.Drawing.Point(7, 18);
            this.radioButton14.Name = "radioButton14";
            this.radioButton14.Size = new System.Drawing.Size(92, 22);
            this.radioButton14.TabIndex = 5;
            this.radioButton14.TabStop = true;
            this.radioButton14.Text = "Employed";
            this.radioButton14.UseVisualStyleBackColor = true;
            this.radioButton14.CheckedChanged += new System.EventHandler(this.radioButton14_CheckedChanged);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.radioButton24);
            this.groupBox7.Controls.Add(this.radioButton22);
            this.groupBox7.Controls.Add(this.radioButton20);
            this.groupBox7.Controls.Add(this.radioButton19);
            this.groupBox7.Controls.Add(this.radioButton23);
            this.groupBox7.Controls.Add(this.textBox15);
            this.groupBox7.Controls.Add(this.radioButton21);
            this.groupBox7.Controls.Add(this.radioButton18);
            this.groupBox7.Controls.Add(this.label24);
            this.groupBox7.Controls.Add(this.textBox14);
            this.groupBox7.Location = new System.Drawing.Point(429, 47);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(461, 184);
            this.groupBox7.TabIndex = 4;
            this.groupBox7.TabStop = false;
            // 
            // radioButton24
            // 
            this.radioButton24.AutoSize = true;
            this.radioButton24.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.radioButton24.Location = new System.Drawing.Point(248, 115);
            this.radioButton24.Name = "radioButton24";
            this.radioButton24.Size = new System.Drawing.Size(123, 22);
            this.radioButton24.TabIndex = 55;
            this.radioButton24.TabStop = true;
            this.radioButton24.Text = "Other, Specify:";
            this.radioButton24.UseVisualStyleBackColor = true;
            this.radioButton24.CheckedChanged += new System.EventHandler(this.radioButton24_CheckedChanged);
            // 
            // radioButton22
            // 
            this.radioButton22.AutoSize = true;
            this.radioButton22.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.radioButton22.Location = new System.Drawing.Point(229, 47);
            this.radioButton22.Name = "radioButton22";
            this.radioButton22.Size = new System.Drawing.Size(212, 22);
            this.radioButton22.TabIndex = 54;
            this.radioButton22.TabStop = true;
            this.radioButton22.Text = "Terminated / Laidoff(abroad)";
            this.radioButton22.UseVisualStyleBackColor = true;
            this.radioButton22.CheckedChanged += new System.EventHandler(this.radioButton22_CheckedChanged);
            // 
            // radioButton20
            // 
            this.radioButton20.AutoSize = true;
            this.radioButton20.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.radioButton20.Location = new System.Drawing.Point(6, 102);
            this.radioButton20.Name = "radioButton20";
            this.radioButton20.Size = new System.Drawing.Size(73, 22);
            this.radioButton20.TabIndex = 52;
            this.radioButton20.TabStop = true;
            this.radioButton20.Text = "Retired";
            this.radioButton20.UseVisualStyleBackColor = true;
            this.radioButton20.CheckedChanged += new System.EventHandler(this.radioButton20_CheckedChanged);
            // 
            // radioButton19
            // 
            this.radioButton19.AutoSize = true;
            this.radioButton19.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.radioButton19.Location = new System.Drawing.Point(6, 46);
            this.radioButton19.Name = "radioButton19";
            this.radioButton19.Size = new System.Drawing.Size(142, 22);
            this.radioButton19.TabIndex = 10;
            this.radioButton19.TabStop = true;
            this.radioButton19.Text = "Finished Contract";
            this.radioButton19.UseVisualStyleBackColor = true;
            this.radioButton19.CheckedChanged += new System.EventHandler(this.radioButton19_CheckedChanged);
            // 
            // radioButton23
            // 
            this.radioButton23.AutoSize = true;
            this.radioButton23.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.radioButton23.Location = new System.Drawing.Point(229, 19);
            this.radioButton23.Name = "radioButton23";
            this.radioButton23.Size = new System.Drawing.Size(197, 22);
            this.radioButton23.TabIndex = 53;
            this.radioButton23.TabStop = true;
            this.radioButton23.Text = "Terminated / Laidoff(local)";
            this.radioButton23.UseVisualStyleBackColor = true;
            this.radioButton23.CheckedChanged += new System.EventHandler(this.radioButton23_CheckedChanged);
            // 
            // textBox15
            // 
            this.textBox15.Enabled = false;
            this.textBox15.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox15.Location = new System.Drawing.Point(248, 143);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(192, 24);
            this.textBox15.TabIndex = 50;
            this.textBox15.Leave += new System.EventHandler(this.textBox15_Leave);
            // 
            // radioButton21
            // 
            this.radioButton21.AutoSize = true;
            this.radioButton21.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.radioButton21.Location = new System.Drawing.Point(6, 74);
            this.radioButton21.Name = "radioButton21";
            this.radioButton21.Size = new System.Drawing.Size(88, 22);
            this.radioButton21.TabIndex = 51;
            this.radioButton21.TabStop = true;
            this.radioButton21.Text = "Resigned";
            this.radioButton21.UseVisualStyleBackColor = true;
            this.radioButton21.CheckedChanged += new System.EventHandler(this.radioButton21_CheckedChanged);
            // 
            // radioButton18
            // 
            this.radioButton18.AutoSize = true;
            this.radioButton18.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.radioButton18.Location = new System.Drawing.Point(6, 18);
            this.radioButton18.Name = "radioButton18";
            this.radioButton18.Size = new System.Drawing.Size(214, 22);
            this.radioButton18.TabIndex = 9;
            this.radioButton18.TabStop = true;
            this.radioButton18.Text = "New Entrant/Fresh Graduate";
            this.radioButton18.UseVisualStyleBackColor = true;
            this.radioButton18.CheckedChanged += new System.EventHandler(this.radioButton18_CheckedChanged);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(248, 70);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(71, 12);
            this.label24.TabIndex = 48;
            this.label24.Text = "Specify Country";
            // 
            // textBox14
            // 
            this.textBox14.Enabled = false;
            this.textBox14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox14.Location = new System.Drawing.Point(248, 85);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(192, 24);
            this.textBox14.TabIndex = 45;
            this.textBox14.Leave += new System.EventHandler(this.textBox14_Leave);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.radioButton17);
            this.groupBox6.Controls.Add(this.radioButton16);
            this.groupBox6.Location = new System.Drawing.Point(7, 47);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(267, 82);
            this.groupBox6.TabIndex = 3;
            this.groupBox6.TabStop = false;
            // 
            // radioButton17
            // 
            this.radioButton17.AutoSize = true;
            this.radioButton17.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.radioButton17.Location = new System.Drawing.Point(7, 46);
            this.radioButton17.Name = "radioButton17";
            this.radioButton17.Size = new System.Drawing.Size(121, 22);
            this.radioButton17.TabIndex = 8;
            this.radioButton17.TabStop = true;
            this.radioButton17.Text = "Self Employed";
            this.radioButton17.UseVisualStyleBackColor = true;
            this.radioButton17.CheckedChanged += new System.EventHandler(this.radioButton17_CheckedChanged);
            // 
            // radioButton16
            // 
            this.radioButton16.AutoSize = true;
            this.radioButton16.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.radioButton16.Location = new System.Drawing.Point(7, 18);
            this.radioButton16.Name = "radioButton16";
            this.radioButton16.Size = new System.Drawing.Size(135, 22);
            this.radioButton16.TabIndex = 7;
            this.radioButton16.TabStop = true;
            this.radioButton16.Text = "Wage Employed";
            this.radioButton16.UseVisualStyleBackColor = true;
            this.radioButton16.CheckedChanged += new System.EventHandler(this.radioButton16_CheckedChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Location = new System.Drawing.Point(28, 2982);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(945, 52);
            this.groupBox4.TabIndex = 45;
            this.groupBox4.TabStop = false;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(460, 16);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(113, 18);
            this.label23.TabIndex = 44;
            this.label23.Text = "Others, Specify:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(13, 510);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(76, 18);
            this.label8.TabIndex = 43;
            this.label8.Text = "Disability";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.checkBox5);
            this.groupBox3.Controls.Add(this.textBox13);
            this.groupBox3.Controls.Add(this.checkBox3);
            this.groupBox3.Controls.Add(this.checkBox4);
            this.groupBox3.Controls.Add(this.checkBox2);
            this.groupBox3.Controls.Add(this.checkBox1);
            this.groupBox3.Location = new System.Drawing.Point(11, 531);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1010, 76);
            this.groupBox3.TabIndex = 24;
            this.groupBox3.TabStop = false;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox5.Location = new System.Drawing.Point(291, 19);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(76, 22);
            this.checkBox5.TabIndex = 45;
            this.checkBox5.Text = "Others:";
            this.checkBox5.UseVisualStyleBackColor = true;
            this.checkBox5.CheckedChanged += new System.EventHandler(this.checkBox5_CheckedChanged);
            // 
            // textBox13
            // 
            this.textBox13.Enabled = false;
            this.textBox13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox13.Location = new System.Drawing.Point(291, 44);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(533, 24);
            this.textBox13.TabIndex = 44;
            this.textBox13.Leave += new System.EventHandler(this.textBox13_Leave);
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox3.Location = new System.Drawing.Point(153, 47);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(82, 22);
            this.checkBox3.TabIndex = 3;
            this.checkBox3.Text = "Physical";
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox4.Location = new System.Drawing.Point(155, 19);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(77, 22);
            this.checkBox4.TabIndex = 2;
            this.checkBox4.Text = "Speech";
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox2.Location = new System.Drawing.Point(6, 47);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(78, 22);
            this.checkBox2.TabIndex = 1;
            this.checkBox2.Text = "Hearing";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.Location = new System.Drawing.Point(8, 19);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(66, 22);
            this.checkBox1.TabIndex = 0;
            this.checkBox1.Text = "Visual";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(543, 459);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(131, 18);
            this.label17.TabIndex = 42;
            this.label17.Text = "Cellphone Number";
            // 
            // textBox9
            // 
            this.textBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox9.Location = new System.Drawing.Point(675, 456);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(347, 24);
            this.textBox9.TabIndex = 41;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(543, 428);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(116, 18);
            this.label18.TabIndex = 40;
            this.label18.Text = "Landing Number";
            // 
            // textBox10
            // 
            this.textBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox10.Location = new System.Drawing.Point(676, 425);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(347, 24);
            this.textBox10.TabIndex = 39;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(543, 398);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(103, 18);
            this.label19.TabIndex = 38;
            this.label19.Text = "Email Address";
            // 
            // textBox11
            // 
            this.textBox11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox11.Location = new System.Drawing.Point(676, 395);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(347, 24);
            this.textBox11.TabIndex = 37;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(545, 368);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(50, 18);
            this.label20.TabIndex = 36;
            this.label20.Text = "Height";
            // 
            // textBox12
            // 
            this.textBox12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox12.Location = new System.Drawing.Point(677, 365);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(347, 24);
            this.textBox12.TabIndex = 35;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(307, 306);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(66, 18);
            this.label16.TabIndex = 34;
            this.label16.Text = "Province";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(307, 275);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(121, 18);
            this.label15.TabIndex = 32;
            this.label15.Text = "Municipality / City";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(307, 245);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(70, 18);
            this.label14.TabIndex = 30;
            this.label14.Text = "Barangay";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(308, 215);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(173, 18);
            this.label13.TabIndex = 28;
            this.label13.Text = "House No./ Street Village";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(590, 191);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(132, 18);
            this.label12.TabIndex = 27;
            this.label12.Text = "Present Address";
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(491, 212);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(533, 24);
            this.textBox5.TabIndex = 26;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(307, 128);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(110, 18);
            this.label11.TabIndex = 25;
            this.label11.Text = "Place of Birth";
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(311, 149);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(713, 24);
            this.textBox4.TabIndex = 24;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(13, 336);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(85, 18);
            this.label10.TabIndex = 22;
            this.label10.Text = "Civil Status:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButton2);
            this.groupBox1.Controls.Add(this.radioButton1);
            this.groupBox1.Location = new System.Drawing.Point(16, 212);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(269, 51);
            this.groupBox1.TabIndex = 21;
            this.groupBox1.TabStop = false;
            // 
            // bunifuSeparator2
            // 
            this.bunifuSeparator2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator2.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator2.LineThickness = 1;
            this.bunifuSeparator2.Location = new System.Drawing.Point(12, 110);
            this.bunifuSeparator2.Name = "bunifuSeparator2";
            this.bunifuSeparator2.Size = new System.Drawing.Size(1054, 15);
            this.bunifuSeparator2.TabIndex = 20;
            this.bunifuSeparator2.Transparency = 255;
            this.bunifuSeparator2.Vertical = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(12, 18);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(188, 20);
            this.label9.TabIndex = 19;
            this.label9.Text = "-Personal Information-";
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator1.LineThickness = 1;
            this.bunifuSeparator1.Location = new System.Drawing.Point(12, 39);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(1054, 15);
            this.bunifuSeparator1.TabIndex = 0;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = false;
            // 
            // NSRP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1100, 600);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "NSRP";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "NSRP";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.groupBox22.ResumeLayout(false);
            this.groupBox22.PerformLayout();
            this.groupBox21.ResumeLayout(false);
            this.groupBox21.PerformLayout();
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label9;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator1;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.RadioButton radioButton12;
        private System.Windows.Forms.RadioButton radioButton13;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.RadioButton radioButton11;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.CheckBox checkBox26;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.CheckBox checkBox27;
        private System.Windows.Forms.CheckBox checkBox28;
        private System.Windows.Forms.CheckBox checkBox29;
        private System.Windows.Forms.CheckBox checkBox22;
        private System.Windows.Forms.CheckBox checkBox23;
        private System.Windows.Forms.CheckBox checkBox24;
        private System.Windows.Forms.CheckBox checkBox25;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.CheckBox checkBox21;
        private System.Windows.Forms.CheckBox checkBox20;
        private System.Windows.Forms.CheckBox checkBox19;
        private System.Windows.Forms.CheckBox checkBox18;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.DateTimePicker dateTimePicker6;
        private System.Windows.Forms.DateTimePicker dateTimePicker7;
        private System.Windows.Forms.DateTimePicker dateTimePicker8;
        private System.Windows.Forms.DateTimePicker dateTimePicker9;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.DateTimePicker dateTimePicker5;
        private System.Windows.Forms.DateTimePicker dateTimePicker4;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.DateTimePicker dateTimePicker13;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.DateTimePicker dateTimePicker14;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.DateTimePicker dateTimePicker11;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.DateTimePicker dateTimePicker12;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.DateTimePicker dateTimePicker10;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.DateTimePicker dateTimePicker17;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.DateTimePicker dateTimePicker15;
        private System.Windows.Forms.DateTimePicker dateTimePicker16;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.TextBox textBox59;
        private System.Windows.Forms.DateTimePicker dateTimePicker19;
        private System.Windows.Forms.TextBox textBox61;
        private System.Windows.Forms.TextBox textBox63;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.DateTimePicker dateTimePicker21;
        private System.Windows.Forms.TextBox textBox65;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.TextBox textBox78;
        private System.Windows.Forms.CheckBox checkBox42;
        private System.Windows.Forms.CheckBox checkBox43;
        private System.Windows.Forms.CheckBox checkBox44;
        private System.Windows.Forms.CheckBox checkBox45;
        private System.Windows.Forms.CheckBox checkBox46;
        private System.Windows.Forms.CheckBox checkBox47;
        private System.Windows.Forms.CheckBox checkBox36;
        private System.Windows.Forms.CheckBox checkBox37;
        private System.Windows.Forms.CheckBox checkBox38;
        private System.Windows.Forms.CheckBox checkBox39;
        private System.Windows.Forms.CheckBox checkBox40;
        private System.Windows.Forms.CheckBox checkBox41;
        private System.Windows.Forms.CheckBox checkBox34;
        private System.Windows.Forms.CheckBox checkBox35;
        private System.Windows.Forms.CheckBox checkBox32;
        private System.Windows.Forms.CheckBox checkBox33;
        private System.Windows.Forms.CheckBox checkBox31;
        private System.Windows.Forms.CheckBox checkBox30;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.DateTimePicker dateTimePicker28;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.DateTimePicker dateTimePicker29;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.DateTimePicker dateTimePicker24;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.DateTimePicker dateTimePicker25;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.DateTimePicker dateTimePicker26;
        private System.Windows.Forms.DateTimePicker dateTimePicker27;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.DateTimePicker dateTimePicker22;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.DateTimePicker dateTimePicker23;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.DateTimePicker dateTimePicker18;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.TextBox textBox73;
        private System.Windows.Forms.DateTimePicker dateTimePicker20;
        private System.Windows.Forms.TextBox textBox74;
        private System.Windows.Forms.TextBox textBox75;
        private System.Windows.Forms.TextBox textBox76;
        private System.Windows.Forms.TextBox textBox77;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.TextBox textBox60;
        private System.Windows.Forms.TextBox textBox62;
        private System.Windows.Forms.TextBox textBox64;
        private System.Windows.Forms.TextBox textBox66;
        private System.Windows.Forms.TextBox textBox72;
        private System.Windows.Forms.TextBox textBox70;
        private System.Windows.Forms.TextBox textBox71;
        private System.Windows.Forms.TextBox textBox69;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.TextBox textBox67;
        private System.Windows.Forms.TextBox textBox68;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.RadioButton radioButton14;
        private System.Windows.Forms.RadioButton radioButton15;
        private System.Windows.Forms.RadioButton radioButton24;
        private System.Windows.Forms.RadioButton radioButton22;
        private System.Windows.Forms.RadioButton radioButton20;
        private System.Windows.Forms.RadioButton radioButton19;
        private System.Windows.Forms.RadioButton radioButton23;
        private System.Windows.Forms.RadioButton radioButton21;
        private System.Windows.Forms.RadioButton radioButton18;
        private System.Windows.Forms.RadioButton radioButton17;
        private System.Windows.Forms.RadioButton radioButton16;
        private System.Windows.Forms.RadioButton radioButton26;
        private System.Windows.Forms.RadioButton radioButton25;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox comboBox10;
        private System.Windows.Forms.ComboBox comboBox9;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox81;
        private System.Windows.Forms.TextBox textBox82;
        private System.Windows.Forms.TextBox textBox83;
        private System.Windows.Forms.ComboBox comboBox11;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.CheckBox checkBox5;
    }
}